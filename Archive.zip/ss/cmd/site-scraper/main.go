// Command site-scraper crawls a set of sites (or a gallery API) and
// downloads the images they reference.
package main

import (
	"bytes"
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"time"

	"main/internal/applog"
	"main/internal/crawl"
	"main/internal/gallery"
	"main/internal/textfile"
)

const maxLogBytes = 10 << 20

func main() {
	staging := time.Now().Format("20060102-150405")

	var (
		useClipboard = flag.Bool("clipboard", false, "read input from the system clipboard")
		site         = flag.String("site", "", "site to scrape")
		inputFile    = flag.String("input", "", "input file containing URLs")
		api          = flag.String("api", "", "gallery API URL that returns json")
		linksFile    = flag.String("links", "", "JSON file of {group: [urls]} to scrape when no other input is given")
	)

	flag.Usage = usage
	flag.Parse()

	home, err := os.UserHomeDir()
	if err != nil {
		fmt.Fprintf(os.Stderr, "resolve home directory: %v\n", err)
		os.Exit(1)
	}

	appDir := filepath.Join(home, ".local", "share", "site-scraper")

	if err := os.MkdirAll(appDir, 0755); err != nil {
		fmt.Fprintf(os.Stderr, "create application directory: %v\n", err)
		os.Exit(1)
	}

	logPath := filepath.Join(appDir, "logs.jsonl")

	logger, logFile, err := applog.Setup(logPath, maxLogBytes)
	if err != nil {
		fmt.Fprintf(os.Stderr, "set up logger: %v\n", err)
		os.Exit(1)
	}
	defer logFile.Close()

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()

	if *linksFile == "" {
		*linksFile = filepath.Join(appDir, "links.json")
	}

	arg := flag.Arg(0)

	var sites []string

	switch {
	case *inputFile != "":
		sites, err = textfile.ReadLines(*inputFile)
		if err != nil {
			logger.Error(
				"reading",
				"inputFile", *inputFile,
				"err", err,
			)
			os.Exit(1)
		}

	case *api != "":
		if err := gallery.Run(ctx, logger, *api, home, staging); err != nil {
			logger.Error(err.Error())
			os.Exit(1)
		}

		os.Exit(0)

	case *site != "":
		sites = []string{*site}

	case *useClipboard:
		lines, err := readClipboard()
		if err != nil {
			logger.Error("reading clipboard", "err", err)
			os.Exit(1)
		}

		sites = lines

	case arg == "":
		data, err := os.ReadFile(*linksFile)
		if err != nil {
			logger.Error(
				"reading links file",
				"file", *linksFile,
				"err", err,
			)
			os.Exit(1)
		}

		var groups map[string][]string

		if err := json.Unmarshal(data, &groups); err != nil {
			logger.Error("error", "err", err)
			os.Exit(1)
		}

		for _, v := range groups {
			sites = append(sites, v...)
		}

	default:
		flag.Usage()
		os.Exit(2)
	}

	if err := crawl.Run(ctx, logger, sites, home, staging, appDir); err != nil {
		logger.Error(err.Error())
		os.Exit(1)
	}
}

func readClipboard() ([]string, error) {
	out, err := exec.Command("pbpaste").Output()
	if err != nil {
		return nil, fmt.Errorf("clipboard read failed: %w", err)
	}

	return textfile.Lines(bytes.NewReader(out))
}

func usage() {
	fmt.Fprintf(os.Stderr, `Usage:
  %s [options]

Downloads and processes galleries.

Options:
`, filepath.Base(os.Args[0]))

	flag.PrintDefaults()

	fmt.Fprintln(os.Stderr, `
Examples:
  myscraper -site https://example.com/gallery
  myscraper -api https://example.com/api/gallery
  myscraper -input urls.txt`)
}
