// Package gallery fetches gallery metadata from a JSON API, downloads each
// item's preview thumbnail, and writes a manifest pairing previews with
// their gallery site URL — letting a human review previews offline before
// choosing which URLs are worth scraping with the crawl package.
package gallery

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"sync"
	"time"

	"golang.org/x/time/rate"

	"main/internal/download"
	"main/internal/httpx"
)

const maxAPIBytes = 50 << 20

// item mirrors one entry returned by the gallery API: GURL is the
// gallery/site page, TURL/TURL460 are preview thumbnails, not images to
// keep.
type item struct {
	Title    string `json:"title"`
	Desc     string `json:"desc"`
	GURL     string `json:"g_url"`
	TURL     string `json:"t_url"`
	TURL460  string `json:"t_url_460"`
	TID      int    `json:"tid"`
	GID      int    `json:"gid"`
	MID      string `json:"mid"`
	H        int    `json:"h"`
	Position int    `json:"position"`
}

// manifestEntry pairs a fetched gallery item with its downloaded preview.
type manifestEntry struct {
	GID         int    `json:"gid"`
	TID         int    `json:"tid"`
	Title       string `json:"title"`
	Desc        string `json:"desc"`
	SiteURL     string `json:"site_url"`
	PreviewPath string `json:"preview_path,omitempty"`
	PreviewErr  string `json:"preview_error,omitempty"`
}

// Run fetches gallery metadata from apiURL, downloads each item's preview
// thumbnail under home/Images/staging/api-previews, and writes
// api-manifest.json. This is a first pass meant to be reiterated on.
func Run(ctx context.Context, logger *slog.Logger, apiURL, home, staging string) error {
	client := httpx.NewClient()
	limiter := rate.NewLimiter(rate.Every(500*time.Millisecond), 1)

	items, err := fetchItems(ctx, client, apiURL)
	if err != nil {
		return fmt.Errorf("fetch gallery items: %w", err)
	}
	logger.Info("fetched gallery items", "count", len(items))

	cache := download.NewContentCache()
	manifest := make([]manifestEntry, len(items))
	sem := make(chan struct{}, httpx.Workers)
	var wg sync.WaitGroup

	for i, it := range items {
		entry := manifestEntry{
			GID:     it.GID,
			TID:     it.TID,
			Title:   it.Title,
			Desc:    it.Desc,
			SiteURL: it.GURL,
		}

		previewURL := it.TURL460
		if !isHTTPURL(previewURL) {
			previewURL = it.TURL
		}

		if !isHTTPURL(previewURL) {
			manifest[i] = entry
			continue
		}

		filename := previewFilename(home, staging, it, previewURL)

		select {
		case sem <- struct{}{}:
		case <-ctx.Done():
			entry.PreviewErr = ctx.Err().Error()
			manifest[i] = entry
			continue
		}

		wg.Go(func() {
			defer func() { <-sem }()

			if download.Exists(filename) {
				entry.PreviewPath = filename
				manifest[i] = entry
				return
			}

			result, err := download.File(ctx, client, limiter, logger, cache, previewURL, filename)
			if err != nil {
				if errors.Is(err, download.ErrNotImage) {
					logger.Warn("preview response was not an image", "url", previewURL, "error", err)
				} else {
					logger.Error("preview download failed", "url", previewURL, "error", err)
				}
				entry.PreviewErr = err.Error()
				manifest[i] = entry
				return
			}

			if result.Duplicate {
				entry.PreviewPath = result.Original
			} else {
				entry.PreviewPath = filename
			}
			manifest[i] = entry
		})
	}

	wg.Wait()

	slices.SortFunc(manifest, func(a, b manifestEntry) int {
		if a.GID != b.GID {
			return a.GID - b.GID
		}
		return a.TID - b.TID
	})

	manifestFile, err := os.Create("api-manifest.json")
	if err != nil {
		return fmt.Errorf("create manifest: %w", err)
	}
	defer manifestFile.Close()

	enc := json.NewEncoder(manifestFile)
	enc.SetIndent("", "  ")
	if err := enc.Encode(manifest); err != nil {
		return fmt.Errorf("write manifest: %w", err)
	}

	logger.Info("wrote api manifest", "file", "api-manifest.json", "items", len(manifest))
	return nil
}

func fetchItems(ctx context.Context, client *http.Client, apiURL string) ([]item, error) {
	req, err := httpx.NewRequest(ctx, http.MethodGet, apiURL)
	if err != nil {
		return nil, fmt.Errorf("create request: %w", err)
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("fetch api: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("bad status: %s", resp.Status)
	}

	var items []item
	if err := json.NewDecoder(io.LimitReader(resp.Body, maxAPIBytes)).Decode(&items); err != nil {
		return nil, fmt.Errorf("decode gallery json: %w", err)
	}

	return items, nil
}

// previewFilename builds a traversal-safe path for a gallery item's preview
// image. GID/TID are API-controlled integers, and the extension is
// allowlisted, so the result never depends on attacker-influenced path
// segments.
func previewFilename(home, staging string, it item, rawURL string) string {
	ext := ".jpg"
	if u, err := url.Parse(rawURL); err == nil {
		switch e := strings.ToLower(filepath.Ext(u.Path)); e {
		case ".jpg", ".jpeg", ".png", ".webp", ".gif":
			ext = e
		}
	}

	return filepath.Join(home, "Images", staging, "api-previews", fmt.Sprintf("%d_%d%s", it.GID, it.TID, ext))
}

func isHTTPURL(s string) bool {
	u, err := url.Parse(s)
	return err == nil && (u.Scheme == "http" || u.Scheme == "https")
}
