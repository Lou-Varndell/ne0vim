// Package download fetches and writes individual image files, verifying
// content by sniffing bytes and deduplicating by content hash across a run.
package download

import (
	"bufio"
	"context"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"golang.org/x/time/rate"
	"lukechampine.com/blake3"

	"main/internal/httpx"
)

const maxDownloadBytes = 200 << 20

// ErrNotImage indicates a fetched response was not an image, distinguishing
// "nothing to download here" from a genuine fetch/write failure.
var ErrNotImage = errors.New("response is not an image")

// ContentCache deduplicates downloaded files by content hash across an
// entire run, so byte-identical images reachable under different URLs are
// only ever written to disk once.
type ContentCache struct {
	mu   sync.Mutex
	seen map[[32]byte]string
}

// NewContentCache returns an empty ContentCache.
func NewContentCache() *ContentCache {
	return &ContentCache{seen: make(map[[32]byte]string)}
}

func (c *ContentCache) check(hash [32]byte, filename string) (duplicate bool, original string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if orig, ok := c.seen[hash]; ok {
		return true, orig
	}
	c.seen[hash] = filename
	return false, ""
}

// Result reports the outcome of a successful File call.
type Result struct {
	Hash string

	// Duplicate is true when this content was already written to disk
	// under Original during this run. When Duplicate is true, filename was
	// NOT created — callers must not assume it exists.
	Duplicate bool
	Original  string
}

// File fetches rawURL, verifies (by sniffing bytes, not trusting the
// Content-Type header) that the response is an image, and writes it to
// filename. If the content is byte-identical to something already written
// earlier in this run, filename is left untouched and Result.Duplicate
// reports the path that actually holds the content.
func File(ctx context.Context, client *http.Client, limiter *rate.Limiter, logger *slog.Logger, cache *ContentCache, rawURL, filename string) (result Result, err error) {
	req, err := httpx.NewRequest(ctx, http.MethodGet, rawURL)
	if err != nil {
		return Result{}, fmt.Errorf("create request: %w", err)
	}

	resp, err := httpx.Do(ctx, client, limiter, logger, req)
	if err != nil {
		return Result{}, fmt.Errorf("fetch %s: %w", rawURL, err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return Result{}, fmt.Errorf("bad status: %s", resp.Status)
	}

	// Sniff the actual bytes rather than trusting the server-supplied
	// Content-Type header, so a mislabeled response can't be silently
	// reported as a successful download (or a real image silently skipped).
	br := bufio.NewReaderSize(resp.Body, 512)
	sniff, err := br.Peek(512)
	if err != nil && err != io.EOF {
		return Result{}, fmt.Errorf("read response: %w", err)
	}

	sniffedType := http.DetectContentType(sniff)
	if !strings.HasPrefix(sniffedType, "image/") {
		return Result{}, fmt.Errorf("%w: sniffed %q (header %q)", ErrNotImage, sniffedType, resp.Header.Get("Content-Type"))
	}

	if err := os.MkdirAll(filepath.Dir(filename), 0755); err != nil {
		return Result{}, fmt.Errorf("create download dir: %w", err)
	}

	tmp, err := os.CreateTemp(filepath.Dir(filename), ".dl-*")
	if err != nil {
		return Result{}, fmt.Errorf("create temp file: %w", err)
	}
	defer func() {
		if cerr := tmp.Close(); cerr != nil && err == nil {
			err = cerr
		}
		if err != nil {
			os.Remove(tmp.Name())
		}
	}()

	h := blake3.New(32, nil)
	if _, err = io.Copy(tmp, io.TeeReader(io.LimitReader(br, maxDownloadBytes), h)); err != nil {
		return Result{}, fmt.Errorf("write download: %w", err)
	}

	var digest [32]byte
	h.Sum(digest[:0])
	hash := hex.EncodeToString(digest[:])

	if dup, orig := cache.check(digest, filename); dup {
		logger.Info("skipping duplicate content", "file", filename, "original", orig)
		if rmErr := os.Remove(tmp.Name()); rmErr != nil {
			return Result{}, fmt.Errorf("remove duplicate temp file: %w", rmErr)
		}
		return Result{Hash: hash, Duplicate: true, Original: orig}, nil
	}

	if err = os.Rename(tmp.Name(), filename); err != nil {
		return Result{}, fmt.Errorf("rename download: %w", err)
	}

	logger.Info("downloaded", "file", filename, "hash", hash)

	return Result{Hash: hash}, nil
}

// HashFile computes filename's content hash, e.g. to compare an existing
// on-disk file against fresh content without re-downloading it.
func HashFile(filename string) (string, error) {
	f, err := os.Open(filename)
	if err != nil {
		return "", fmt.Errorf("open file: %w", err)
	}
	defer f.Close()

	h := blake3.New(32, nil)
	if _, err := io.Copy(h, f); err != nil {
		return "", fmt.Errorf("hash file: %w", err)
	}

	var digest [32]byte
	h.Sum(digest[:0])

	return hex.EncodeToString(digest[:]), nil
}

// Exists reports whether path exists.
func Exists(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}
