// Package crawl fetches a set of sites, downloads every image they
// reference, and persists an image manifest plus a deduplicated link set.
package crawl

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/url"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"golang.org/x/time/rate"

	"main/internal/download"
	"main/internal/httpx"
	"main/internal/manifest"
	"main/internal/scrape"
	"main/internal/textfile"
)

const linksFilename = "site-scraper.links.txt"

type imageDownload struct {
	Site       string
	SourceURL  string
	Filename   string
	Discovered time.Time

	Hash   string
	Status string
	Error  string

	// Original is set when Status is "duplicate": the path that actually
	// holds this content, since Filename itself was never written.
	Original string
}

// Run crawls each site in sites, downloads every image it finds, and writes
// an image manifest under home/Images/staging and the accumulated link set
// under appDir.
func Run(
	ctx context.Context,
	logger *slog.Logger,
	sites []string,
	home string,
	staging string,
	appDir string,
) error {
	session := httpx.NewClient()
	limiter := rate.NewLimiter(rate.Every(500*time.Millisecond), 1)
	cache := scrape.NewCache()

	type siteResult struct {
		urls *scrape.Result
		err  error
	}

	results := make(chan siteResult, len(sites))

	var wg sync.WaitGroup

	for _, site := range sites {
		wg.Go(func() {
			logger.Info("site", "site", site)

			urls, err := scrape.Site(
				ctx,
				session,
				limiter,
				logger,
				cache,
				site,
			)

			results <- siteResult{
				urls: urls,
				err:  err,
			}
		})
	}

	go func() {
		wg.Wait()
		close(results)
	}()

	var downloads []imageDownload
	seenURLs := make(map[string]struct{})
	links := make(map[string]struct{})

	for r := range results {
		if r.err != nil {
			logger.Error(
				"failed to collect URLs",
				"error", r.err,
			)
			continue
		}

		for imgURL := range r.urls.Images {
			// The same image URL can surface more than once (an <img src>
			// that's also its own parent-anchor href, or the same image
			// referenced from multiple crawled sites); skip re-enqueuing it
			// so it isn't downloaded concurrently by two workers.
			if _, dup := seenURLs[imgURL]; dup {
				continue
			}

			seenURLs[imgURL] = struct{}{}

			filename, err := filenameFromURL(
				home,
				staging,
				imgURL,
			)
			if err != nil {
				logger.Error(
					"failed to generate filename",
					"site", r.urls.Site,
					"url", imgURL,
					"error", err,
				)
				continue
			}

			downloads = append(downloads, imageDownload{
				Site:       r.urls.Site,
				SourceURL:  imgURL,
				Filename:   filename,
				Discovered: time.Now(),
			})
		}

		for u := range r.urls.Links {
			logger.Info("found link", "url", u)
			links[u] = struct{}{}
		}
	}

	logger.Info("found images", "count", len(downloads))
	logger.Info("found links", "count", len(links))

	contentDedup := download.NewContentCache()
	sem := make(chan struct{}, httpx.Workers)

	var dlWg sync.WaitGroup
	var failures atomic.Int64
	var completed atomic.Int64

	totalDownloads := len(downloads)

loop:
	for i := range downloads {
		select {
		case sem <- struct{}{}:
		case <-ctx.Done():
			break loop
		}

		dlWg.Go(func() {
			defer func() {
				<-sem

				pos := completed.Add(1)

				logger.Info(
					"download progress",
					"current", pos,
					"total", totalDownloads,
				)
			}()

			d := &downloads[i]

			if download.Exists(d.Filename) {
				hash, err := download.HashFile(d.Filename)
				if err != nil {
					d.Status = "failed"
					d.Error = err.Error()
					return
				}

				d.Hash = hash
				d.Status = "existing"

				logger.Info(
					"skipping existing file",
					"site", d.Site,
					"file", d.Filename,
					"hash", hash,
				)

				return
			}

			result, err := download.File(
				ctx,
				session,
				limiter,
				logger,
				contentDedup,
				d.SourceURL,
				d.Filename,
			)

			if err != nil {
				d.Error = err.Error()

				if errors.Is(err, download.ErrNotImage) {
					d.Status = "skipped"

					logger.Warn(
						"skipping non-image response",
						"site", d.Site,
						"url", d.SourceURL,
						"error", err,
					)

					return
				}

				d.Status = "failed"

				logger.Error(
					"download failed",
					"site", d.Site,
					"url", d.SourceURL,
					"error", err,
				)

				failures.Add(1)

				return
			}

			d.Hash = result.Hash

			if result.Duplicate {
				d.Status = "duplicate"
				d.Original = result.Original
				return
			}

			d.Status = "downloaded"
		})
	}

	dlWg.Wait()

	entries := make([]manifest.Entry, 0, len(downloads))

	for _, d := range downloads {
		entries = append(entries, manifest.Entry{
			Site:         d.Site,
			SourceURL:    d.SourceURL,
			File:         d.Filename,
			Hash:         d.Hash,
			Status:       d.Status,
			Error:        d.Error,
			Original:     d.Original,
			DiscoveredAt: d.Discovered,
		})
	}

	manifestFilePath := manifestPath(home, staging)

	if err := os.MkdirAll(
		filepath.Dir(manifestFilePath),
		0755,
	); err != nil {
		return fmt.Errorf("create manifest dir: %w", err)
	}

	manifestFile, err := os.Create(manifestFilePath)
	if err != nil {
		return err
	}
	defer manifestFile.Close()

	enc := json.NewEncoder(manifestFile)
	enc.SetIndent("", "  ")

	if err := enc.Encode(entries); err != nil {
		return fmt.Errorf("write image manifest: %w", err)
	}

	logger.Info(
		"wrote image manifest",
		"file", manifestFilePath,
		"images", len(entries),
	)

	if err := writeLinks(appDir, links); err != nil {
		return err
	}

	if n := failures.Load(); n > 0 {
		return fmt.Errorf("%d download(s) failed", n)
	}

	return nil
}

// filenameFromURL builds a traversal-safe on-disk path for rawURL under
// home/Images/staging/<host>/..., rejecting any result that would land
// outside that root.
func filenameFromURL(home, staging, rawURL string) (string, error) {
	u, err := url.Parse(rawURL)
	if err != nil {
		return "", fmt.Errorf("parse url: %w", err)
	}

	rel := filepath.Clean(
		filepath.FromSlash(
			strings.TrimPrefix(u.Path, "/"),
		),
	)

	switch {
	case rel == ".":
		rel = "index.html"

	case strings.HasSuffix(u.Path, "/"):
		rel = filepath.Join(rel, "index.html")
	}

	root := filepath.Join(
		home,
		"Images",
		staging,
		u.Hostname(),
	)

	full := filepath.Join(root, rel)

	if relCheck, err := filepath.Rel(root, full); err != nil ||
		strings.HasPrefix(relCheck, "..") {
		return "", fmt.Errorf(
			"refusing to write outside %s: %s",
			root,
			full,
		)
	}

	return full, nil
}

func manifestPath(home, staging string) string {
	return filepath.Join(
		home,
		"Images",
		staging,
		"image-manifest.json",
	)
}

// writeLinks merges newLinks into the persisted link set at
// appDir/site-scraper.links.txt and rewrites the file with the sorted union,
// so repeated runs accumulate a deduplicated set instead of an ever-growing
// list of repeats.
func writeLinks(appDir string, newLinks map[string]struct{}) error {
	if err := os.MkdirAll(appDir, 0755); err != nil {
		return err
	}

	path := filepath.Join(appDir, linksFilename)

	existing, err := textfile.ReadLines(path)
	if err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("read existing links: %w", err)
	}

	all := make(map[string]struct{}, len(existing)+len(newLinks))

	for _, l := range existing {
		all[l] = struct{}{}
	}

	for l := range newLinks {
		all[l] = struct{}{}
	}

	list := make([]string, 0, len(all))

	for s := range all {
		list = append(list, s)
	}

	slices.Sort(list)

	f, err := os.OpenFile(
		path,
		os.O_WRONLY|os.O_CREATE|os.O_TRUNC,
		0644,
	)
	if err != nil {
		return err
	}
	defer f.Close()

	w := bufio.NewWriter(f)

	for _, s := range list {
		fmt.Fprintln(w, s)
	}

	return w.Flush()
}
