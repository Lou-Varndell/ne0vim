// Package scrape fetches an HTML page and extracts the image and same-host
// link URLs it references, deduplicating concurrent and repeat fetches of
// the same page within a run.
package scrape

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"

	"github.com/PuerkitoBio/goquery"
	"golang.org/x/time/rate"

	"main/internal/httpx"
)

const maxPageBytes = 50 << 20
const maxCacheBytes = 200 << 20

// Result holds every image and same-host link discovered on one site.
type Result struct {
	Site   string
	Images map[string]struct{}
	Links  map[string]struct{}
}

// page holds the outcome of fetching one URL, computed at most once.
type page struct {
	once        sync.Once
	statusCode  int
	contentType string
	body        []byte
	finalURL    *url.URL
	err         error
}

// Cache deduplicates concurrent and repeat fetches of the same URL within a
// single run, so a page is downloaded once and its body is reused by every
// caller that needs it (e.g. an href that also appears as an <img> parent
// link). Cached bodies are bounded by maxCacheBytes; entries evicted to stay
// under that bound are simply re-fetched if referenced again, so eviction
// never produces incorrect (missing/stale) data — only a cache miss.
type Cache struct {
	mu         sync.Mutex
	pages      map[string]*page
	order      []string
	totalBytes int64
}

// NewCache returns an empty page Cache.
func NewCache() *Cache {
	return &Cache{pages: make(map[string]*page)}
}

func (c *Cache) fetch(ctx context.Context, client *http.Client, limiter *rate.Limiter, logger *slog.Logger, rawURL string) (*page, error) {
	c.mu.Lock()
	entry, ok := c.pages[rawURL]
	if !ok {
		entry = &page{}
		c.pages[rawURL] = entry
	}
	c.mu.Unlock()

	entry.once.Do(func() {
		req, err := httpx.NewRequest(ctx, http.MethodGet, rawURL)
		if err != nil {
			entry.err = fmt.Errorf("create request: %w", err)
			return
		}

		resp, err := httpx.Do(ctx, client, limiter, logger, req)
		if err != nil {
			entry.err = fmt.Errorf("fetch %s: %w", rawURL, err)
			logger.Error("failed to fetch page", "url", rawURL, "error", err)
			return
		}
		defer resp.Body.Close()

		entry.statusCode = resp.StatusCode
		entry.contentType = resp.Header.Get("Content-Type")
		entry.finalURL = resp.Request.URL

		if resp.StatusCode != http.StatusOK {
			logger.Error("bad status for page", "url", rawURL, "status", resp.Status)
			return
		}

		if strings.HasPrefix(entry.contentType, "image/") {
			return
		}

		body, err := io.ReadAll(io.LimitReader(resp.Body, maxPageBytes))
		if err != nil {
			entry.err = fmt.Errorf("read body: %w", err)
			return
		}
		entry.body = body
		c.remember(rawURL, len(body))
	})

	return entry, entry.err
}

// remember tracks rawURL's cached body size and evicts the oldest cached
// pages once total cached bytes exceed maxCacheBytes, so a long crawl with
// many distinct pages can't grow the Cache without bound. Evicting an entry
// only makes it a cache miss on the next fetch — anyone already holding a
// reference to it (returned before eviction) still sees its intact body.
func (c *Cache) remember(rawURL string, size int) {
	c.mu.Lock()
	defer c.mu.Unlock()

	c.order = append(c.order, rawURL)
	c.totalBytes += int64(size)

	for c.totalBytes > maxCacheBytes && len(c.order) > 0 {
		oldest := c.order[0]
		c.order = c.order[1:]
		if e, ok := c.pages[oldest]; ok {
			c.totalBytes -= int64(len(e.body))
			delete(c.pages, oldest)
		}
	}
}

// Site fetches site, parses its HTML, and returns every image and
// same-host link it finds. Link-following is scoped to the same host as
// the (post-redirect) page itself, to avoid following scraped content to
// attacker-influenced or unrelated destinations; images are not host-scoped
// since they're legitimately served from CDNs on other hosts.
func Site(ctx context.Context, client *http.Client, limiter *rate.Limiter, logger *slog.Logger, cache *Cache, site string) (*Result, error) {
	result := &Result{
		Site:   site,
		Images: make(map[string]struct{}),
		Links:  make(map[string]struct{}),
	}

	siteURL, err := url.Parse(strings.TrimSpace(site))
	if err != nil {
		return nil, fmt.Errorf("parse site URL: %w", err)
	}

	p, err := cache.fetch(ctx, client, limiter, logger, siteURL.String())
	if err != nil {
		return nil, err
	}
	if p.statusCode != http.StatusOK {
		return nil, fmt.Errorf("bad status: %d", p.statusCode)
	}

	base := p.finalURL

	doc, err := goquery.NewDocumentFromReader(bytes.NewReader(p.body))
	if err != nil {
		return nil, fmt.Errorf("parse HTML: %w", err)
	}

	doc.Find("img").Each(func(_ int, s *goquery.Selection) {
		if u, ok := imageURL(base, s); ok {
			result.Images[u] = struct{}{}
		}
		if a, ok := findParentAnchor(s); ok {
			if href, ok := a.Attr("href"); ok {
				if abs, ok := resolveURL(base, href); ok {
					result.Images[abs] = struct{}{}
				}
			}
		}
	})

	doc.Find("a").Each(func(_ int, s *goquery.Selection) {
		link, ok := s.Attr("href")
		if !ok {
			return
		}

		abs, ok := resolveURL(base, link)
		if !ok {
			return
		}

		linkURL, err := url.Parse(abs)
		if err != nil || !strings.EqualFold(linkURL.Hostname(), base.Hostname()) {
			return
		}

		linkPage, err := cache.fetch(ctx, client, limiter, logger, abs)
		if err != nil || linkPage.statusCode != http.StatusOK || strings.HasPrefix(linkPage.contentType, "image/") {
			return
		}

		result.Links[abs] = struct{}{}
	})

	return result, nil
}

var srcsetAttrs = []string{"data-srcset", "srcset"}

var imageAttrs = []string{
	"data-original",
	"data-lazy-src",
	"data-src",
	"src",
	"href",
	"srcset",
}

func imageURL(base *url.URL, img *goquery.Selection) (string, bool) {
	var best string

	for _, attr := range srcsetAttrs {
		if val, ok := img.Attr(attr); ok {
			if u := parseSrcset(val); u != "" {
				if resolved, ok := resolveURL(base, u); ok {
					best = resolved
					break
				}
			}
		}
	}

	if best == "" {
		for _, attr := range imageAttrs {
			if val, ok := img.Attr(attr); ok && val != "" {
				if resolved, ok := resolveURL(base, val); ok {
					best = resolved
					break
				}
			}
		}
	}

	return best, best != ""
}

func findParentAnchor(s *goquery.Selection) (*goquery.Selection, bool) {
	for p := s.Parent(); p.Length() > 0; p = p.Parent() {
		if goquery.NodeName(p) == "a" {
			return p, true
		}
	}
	return nil, false
}

func parseSrcset(srcset string) string {
	var (
		bestURL     string
		bestW       int
		bestX       float64
		fallbackURL string
	)

	for candidate := range strings.SplitSeq(srcset, ",") {
		fields := strings.Fields(strings.TrimSpace(candidate))
		if len(fields) == 0 {
			continue
		}

		rawURL := fields[0]

		if len(fields) == 1 {
			if fallbackURL == "" {
				fallbackURL = rawURL
			}
			continue
		}

		d := fields[1]

		if wStr, ok := strings.CutSuffix(d, "w"); ok {
			w, err := strconv.Atoi(wStr)
			if err == nil && w > bestW {
				bestW = w
				bestURL = rawURL
			}
			continue
		}

		if xStr, ok := strings.CutSuffix(d, "x"); ok {
			x, err := strconv.ParseFloat(xStr, 64)
			if err == nil && x > bestX {
				bestX = x
				bestURL = rawURL
			}
		}
	}

	if bestURL == "" {
		bestURL = fallbackURL
	}

	return bestURL
}

func resolveURL(base *url.URL, ref string) (string, bool) {
	u, err := base.Parse(ref)
	if err != nil {
		return "", false
	}

	if u.Scheme != "http" && u.Scheme != "https" {
		return "", false
	}

	return u.String(), true
}
