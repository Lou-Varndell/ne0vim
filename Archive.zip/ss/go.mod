module main

go 1.26.4

require (
	github.com/PuerkitoBio/goquery v1.12.0
	golang.org/x/time v0.15.0
	lukechampine.com/blake3 v1.4.1
)

require (
	github.com/andybalholm/cascadia v1.3.3 // indirect
	github.com/klauspost/cpuid/v2 v2.0.9 // indirect
	golang.org/x/net v0.52.0 // indirect
)
