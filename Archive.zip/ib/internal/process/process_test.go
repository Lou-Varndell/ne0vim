package process

import (
	"context"
	"encoding/json"
	"image"
	"image-browser/internal/manifest"
	"image/png"
	"os"
	"path/filepath"
	"testing"
)

func TestDefaultOutput(t *testing.T) {
	got := defaultOutput("/tmp/image-manifest.json")
	want := "/tmp/processed-image-manifest.json"
	if got != want {
		t.Fatalf("defaultOutput() = %q, want %q", got, want)
	}
}

func TestIsImageFile(t *testing.T) {
	for _, path := range []string{"image.jpg", "image.JPEG", "image.png", "image.gif", "image.webp"} {
		if !isImageFile(path) {
			t.Errorf("isImageFile(%q) = false, want true", path)
		}
	}

	for _, path := range []string{"image.svg", "image.avif", "image.php", "image", ""} {
		if isImageFile(path) {
			t.Errorf("isImageFile(%q) = true, want false", path)
		}
	}
}

func TestImageDimensions(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "test.png")

	file, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}

	img := image.NewRGBA(image.Rect(0, 0, 37, 53))
	if err := png.Encode(file, img); err != nil {
		file.Close()
		t.Fatal(err)
	}
	if err := file.Close(); err != nil {
		t.Fatal(err)
	}

	width, height, err := imageDimensions(path)
	if err != nil {
		t.Fatal(err)
	}
	if width != 37 || height != 53 {
		t.Fatalf("imageDimensions() = %dx%d, want 37x53", width, height)
	}
}

func TestProcessImageFileRejectsNonImage(t *testing.T) {
	width, height, err := processImageFile("example.php")
	if width != 0 || height != 0 {
		t.Fatalf("processImageFile() dimensions = %dx%d, want 0x0", width, height)
	}
	if err != errNonImage {
		t.Fatalf("processImageFile() error = %v, want %v", err, errNonImage)
	}
}

func TestFilterExistingFiles(t *testing.T) {
	dir := t.TempDir()
	existing := filepath.Join(dir, "existing.jpg")
	if err := os.WriteFile(existing, []byte("test"), 0o644); err != nil {
		t.Fatal(err)
	}

	data := []manifest.Entry{
		{File: existing},
		{File: filepath.Join(dir, "missing.jpg")},
		{File: ""},
	}

	kept, removedMissing, droppedEmpty := filterExistingFiles(data, 2)
	if len(kept) != 1 || kept[0].File != existing {
		t.Fatalf("kept = %#v, want only %q", kept, existing)
	}
	if removedMissing != 1 {
		t.Fatalf("removedMissing = %d, want 1", removedMissing)
	}
	if droppedEmpty != 1 {
		t.Fatalf("droppedEmpty = %d, want 1", droppedEmpty)
	}
}

func TestProcessImages(t *testing.T) {
	dir := t.TempDir()
	imagePath := filepath.Join(dir, "image.png")
	missingPath := filepath.Join(dir, "missing.jpg")
	otherPath := filepath.Join(dir, "notes.php")
	manifestPath := filepath.Join(dir, "image-manifest.json")
	outputPath := filepath.Join(dir, "processed-image-manifest.json")

	file, err := os.Create(imagePath)
	if err != nil {
		t.Fatal(err)
	}
	if err := png.Encode(file, image.NewRGBA(image.Rect(0, 0, 17, 29))); err != nil {
		file.Close()
		t.Fatal(err)
	}
	if err := file.Close(); err != nil {
		t.Fatal(err)
	}

	data := []manifest.Entry{
		{File: imagePath, Status: "discovered"},
		{File: imagePath, Status: "discovered"},
		{File: missingPath, Status: "discovered"},
		{File: otherPath, Status: "discovered"},
		{File: "", Status: "discovered"},
	}

	manifestJSON, err := json.Marshal(data)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(otherPath, []byte("not an image"), 0o644); err != nil {
		t.Fatal(err)
	}

	if err := os.WriteFile(manifestPath, manifestJSON, 0o644); err != nil {
		t.Fatal(err)
	}

	if err := processImages(context.Background(), manifestPath, outputPath, 2, 0); err != nil {
		t.Fatal(err)
	}

	output, err := os.ReadFile(outputPath)
	if err != nil {
		t.Fatal(err)
	}

	var got []manifest.Entry
	if err := json.Unmarshal(output, &got); err != nil {
		t.Fatal(err)
	}
	if len(got) != 3 {
		t.Fatalf("output records = %d, want 3", len(got))
	}
	for i, record := range got[:2] {
		if record.Width != 17 || record.Height != 29 || record.Status != "processed" {
			t.Errorf("record %d = %#v, want processed 17x29", i, record)
		}
	}
	if got[2].Status != "failed" {
		t.Errorf("non-image status = %q, want failed", got[2].Status)
	}
}
