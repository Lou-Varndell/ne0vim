package process

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"image"
	"image-browser/internal/manifest"
	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"

	_ "golang.org/x/image/webp"
)

func isImageFile(path string) bool {
	ext := strings.ToLower(filepath.Ext(path))
	return imageExtensions[ext]
}

func imageDimensions(filePath string) (width, height int, err error) {
	file, err := os.Open(filePath)
	if err != nil {
		return 0, 0, err
	}
	defer func() {
		if cerr := file.Close(); cerr != nil && err == nil {
			err = cerr
		}
	}()

	config, _, err := image.DecodeConfig(file)
	if err != nil {
		return 0, 0, err
	}
	if config.Width <= 0 || config.Height <= 0 {
		return 0, 0, errors.New("invalid dimensions")
	}
	return config.Width, config.Height, nil
}

func processImageFile(filePath string) (int, int, error) {
	if filePath == "" {
		return 0, 0, errors.New("empty file path")
	}
	if !isImageFile(filePath) {
		return 0, 0, errNonImage
	}
	return imageDimensions(filePath)
}

func worker(ctx context.Context, jobs <-chan job, results chan<- result, wg *sync.WaitGroup) {
	defer wg.Done()

	for item := range jobs {
		width, height, err := processImageFile(item.file)
		select {
		case results <- result{file: item.file, width: width, height: height, err: err}:
		case <-ctx.Done():
			return
		}
	}
}

func writeJSON(outputFile string, data []manifest.Entry) error {
	dir := filepath.Dir(outputFile)
	tempFile, err := os.CreateTemp(dir, ".checkpoint-*")
	if err != nil {
		return fmt.Errorf("creating temporary output file: %w", err)
	}

	tempName := tempFile.Name()
	renamed := false
	defer func() {
		if !renamed {
			_ = os.Remove(tempName)
		}
	}()

	if err := tempFile.Chmod(0o644); err != nil {
		_ = tempFile.Close()
		return fmt.Errorf("setting permissions on %s: %w", tempName, err)
	}

	encoder := json.NewEncoder(tempFile)
	encoder.SetIndent("", "  ")
	if err := encoder.Encode(data); err != nil {
		_ = tempFile.Close()
		return fmt.Errorf("encoding %s: %w", tempName, err)
	}
	if err := tempFile.Close(); err != nil {
		return fmt.Errorf("closing %s: %w", tempName, err)
	}
	if err := os.Rename(tempName, outputFile); err != nil {
		return fmt.Errorf("renaming %s to %s: %w", tempName, outputFile, err)
	}

	renamed = true
	return nil
}

func filterExistingFiles(data []manifest.Entry, maxWorkers int) (kept []manifest.Entry, removedMissing, droppedEmpty int) {
	keep := make([]bool, len(data))
	sem := make(chan struct{}, maxWorkers)
	var wg sync.WaitGroup

	for i, item := range data {
		if item.File == "" {
			droppedEmpty++
			continue
		}

		wg.Add(1)
		sem <- struct{}{}
		go func(i int, path string) {
			defer wg.Done()
			defer func() { <-sem }()

			_, err := os.Stat(path)
			switch {
			case err == nil:
				keep[i] = true
			case errors.Is(err, os.ErrNotExist):
				keep[i] = false
			default:
				log.Printf("cannot stat %s: %v", path, err)
				keep[i] = true
			}
		}(i, item.File)
	}

	wg.Wait()
	kept = data[:0]
	for i, item := range data {
		if keep[i] {
			kept = append(kept, item)
		}
	}

	removedMissing = len(data) - len(kept) - droppedEmpty
	return kept, removedMissing, droppedEmpty
}
