package viewer

import (
	"errors"
	"flag"
	"fmt"
	"os"
	"sync"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"

	"image-browser/internal/images"
	"image-browser/internal/paths"
)

// Run executes the view command and starts the Fyne application.
func Run(args []string) error {
	fs := flag.NewFlagSet("view", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)

	root := fs.String("root", "", "root directory to search (default: ~/Images)")

	fs.Usage = func() {
		fmt.Fprintln(os.Stderr, "Usage: image-browser view [pattern] [flags]")
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "Flags:")
		fs.PrintDefaults()
	}

	if err := fs.Parse(args); err != nil {
		return err
	}

	positional := fs.Args()

	var pattern string
	switch len(positional) {
	case 0:
		// No pattern.
	case 1:
		pattern = positional[0]
	default:
		return errors.New("view: too many positional arguments")
	}

	rootPath := *root
	if rootPath == "" {
		rootPath = paths.DefaultRoot()
	}

	rootPath, err := paths.Abs(rootPath)
	if err != nil {
		return err
	}

	info, err := os.Stat(rootPath)
	if err != nil {
		return fmt.Errorf("not a directory: %s", rootPath)
	}

	if !info.IsDir() {
		return fmt.Errorf("not a directory: %s", rootPath)
	}

	matches, err := images.Find(rootPath, pattern)
	if err != nil {
		return err
	}

	if len(matches) == 0 {
		fmt.Printf("No images found for %q under %s\n", pattern, rootPath)
		return nil
	}

	return RunImages(rootPath, pattern, matches, true)
}

// RunImages displays the supplied image paths in the image browser.
// allowTrash controls whether the browser's individual-file trash shortcuts
// are enabled.
func RunImages(root, pattern string, matches []string, allowTrash bool) error {
	session := NewSession()
	session.ShowImages(root, pattern, matches, allowTrash)
	session.Run()
	session.Wait()
	session.Quit()
	return nil
}

// Session owns one Fyne application and window that can be reused for
// multiple image batches. Fyne applications have a single run loop, so a
// session is required when a command needs to show several previews in
// sequence.
type Session struct {
	app  fyne.App
	win  fyne.Window
	mu   sync.Mutex
	done chan struct{}
}

// NewSession creates a reusable image-browser session.
func NewSession() *Session {
	a := app.NewWithID("com.example.image-browser")
	win := a.NewWindow("Image Browser")
	win.Resize(fyne.NewSize(1000, 700))

	s := &Session{
		app:  a,
		win:  win,
		done: make(chan struct{}, 1),
	}

	win.SetCloseIntercept(func() {
		win.Hide()
		s.mu.Lock()
		select {
		case s.done <- struct{}{}:
		default:
		}
		s.mu.Unlock()
	})

	return s
}

// ShowImages replaces the window contents with a new batch and shows it.
func (s *Session) ShowImages(root, pattern string, matches []string, allowTrash bool) {
	done := make(chan struct{})

	s.mu.Lock()
	s.done = make(chan struct{}, 1)
	s.mu.Unlock()

	fyne.Do(func() {
		browser := New(s.app, s.win, root, pattern, matches, true, true)
		browser.SetTrashEnabled(allowTrash)
		browser.Show()
		s.win.Show()
		close(done)
	})

	<-done
}

// Run starts the session's Fyne event loop. It must only be called once and
// must be called from the main goroutine.
func (s *Session) Run() {
	s.app.Run()
}

// Wait waits until the current preview window is closed.
func (s *Session) Wait() {
	<-s.done
}

// Quit stops the Fyne application from within Fyne's event loop.
//
// This method may be called from a non-Fyne goroutine, such as the size
// command's review loop. Directly calling App.Quit from that goroutine
// triggers Fyne's threading safety check, so the call is marshalled through
// fyne.Do.
func (s *Session) Quit() {
	fyne.Do(func() {
		s.app.Quit()
	})
}
