from bs4 import BeautifulSoup
import requests
from PIL import Image
from io import BytesIO
from subprocess import run
from pathlib import Path
from urllib.parse import urljoin, urlparse
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from blake3 import blake3
import logging
import re


HASH_CHUNK_SIZE = 1 << 20  # 1 MiB
DEFAULT_TIMEOUT = (5, 30)
LOGGER = logging.getLogger(__name__)
# logging.basicConfig(
#     level=logging.INFO,
#     format="%(levelname)s: %(message)s",
# )


def create_session():
    """Create a requests session with retries."""

    session = requests.Session()

    retries = Retry(
        total=5,
        connect=5,
        read=5,
        status=5,
        backoff_factor=2,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods={"GET"},
        respect_retry_after_header=True,
    )

    adapter = HTTPAdapter(max_retries=retries)

    session.mount("http://", adapter)
    session.mount("https://", adapter)

    session.headers.update(
        {
            "User-Agent": (
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/137.0.0.0 Safari/537.36"
            )
        }
    )

    return session


def get_image_url(img, page_url):
    """Extract the best image URL from an <img> tag."""

    # srcset usually contains multiple resolutions
    if srcset := img.get("srcset"):
        # Choose the highest-resolution image
        candidates = [entry.strip().split()[0] for entry in srcset.split(",")]

        if candidates:
            return urljoin(page_url, candidates[-1])

    # Common lazy-loading attribute
    if data_src := img.get("data-src"):
        return urljoin(page_url, data_src)

    # Normal images
    if src := img.get("src"):
        return urljoin(page_url, src)

    return None


def download_images(session, url, selector="img", output_dir="downloaded_images"):
    """Download images matching a CSS selector."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    response = session.get(url, timeout=DEFAULT_TIMEOUT)
    response.raise_for_status()

    soup = BeautifulSoup(response.text, "html.parser")

    for img in soup.select(selector) or soup.find_all("img"):
        image_url = get_image_url(img, url)

        if image_url is None:
            continue

        filename = Path(urlparse(image_url).path).name

        if not filename:
            print(f"Skipping URL without filename: {image_url}")
            LOGGER.warning("Skipping URL without filename: image_url=%s", image_url)
            continue

        destination = output_dir / filename

        # Skip existing files
        if destination.exists():
            LOGGER.info("Skipping existing file: filename=%s", filename)
            continue

        try:
            with session.get(
                image_url, stream=True, timeout=DEFAULT_TIMEOUT
            ) as response:
                response.raise_for_status()

                with destination.open("wb") as file:
                    for chunk in response.iter_content(chunk_size=1024 * 1024):
                        file.write(chunk)
            LOGGER.info("Downloaded image: filename=%s", filename)

        except requests.RequestException as exc:
            LOGGER.error(
                "Failed to download image: image_url=%s, error=%s", image_url, str(exc)
            )


def checksum_file(path, chunk_size=HASH_CHUNK_SIZE):
    """Return BLAKE3 hex digest for a file, streamed in fixed-size chunks."""
    hasher = blake3()
    with path.open("rb") as fh:
        while chunk := fh.read(chunk_size):
            hasher.update(chunk)
    digest = hasher.hexdigest()
    return digest


def extract(session, url):
    with session.get(
        url,
        timeout=DEFAULT_TIMEOUT,
    ) as response:
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "lxml")

        img = soup.find("img", alt="Rate this image")
        if not img:
            return None

        image_url = img["src"]

        # Handle relative URLs
        if not image_url.startswith("http"):
            image_url = urljoin(url, image_url)

        container = img.parent

        while container:
            link = container.find("h3")
            if link and link.a:
                return {
                    "page_url": link.a["href"],
                    "title": link.a.get_text(strip=True),
                    "image_url": image_url,
                }

            container = container.parent

    return None


def preview_image(session, image_url):
    try:
        response = session.get(
            image_url,
            timeout=DEFAULT_TIMEOUT,
        )
        response.raise_for_status()

        # Load image using PIL
        image = Image.open(BytesIO(response.content))

        # Display the image (this will open in default image viewer)
        image.show()
        LOGGER.info("Image preview opened: image_url=%s", image_url)

    except (
        requests.RequestException,
        OSError,
        Image.UnidentifiedImageError,
    ) as exc:
        LOGGER.error(
            "Failed to load image: image_url=%s, error=%s", image_url, str(exc)
        )


def main():
    with create_session() as session:
        url = "https://collegepill.com/rate-bikini-pictures"
        data = extract(session, url)

        if data:
            LOGGER.info(
                "Found image: title=%s, page_url=%s, image_url=%s",
                data["title"],
                data["page_url"],
                data["image_url"],
            )
            # Preview the image
            preview_image(session, data["image_url"])
            safe_title = re.sub(
                r"[^\w.-]+",
                "_",
                data["title"],
            ).strip("_")
            download_images(
                session,
                data["page_url"],
                selector="div.gallery img",
                output_dir=safe_title,
            )
        else:
            LOGGER.info("No image found.")


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)s: %(message)s",
    )

    main()

    run(
        ["pbcopy"],
        input="copy([...document.images].map(img => img.src).join('\\n'));",
        text=True,
        check=True,
    )
