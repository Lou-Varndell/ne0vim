package main

import (
	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"

	"context"
	"errors"
	"flag"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"syscall"
	"time"

	"media-manager/internal/catalog"
	"media-manager/internal/review"
	"media-manager/internal/scraper"

	"github.com/alexedwards/scs/v2"
	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
)

func main() {
	imageDirFlag := flag.String("image-dir", "", "directory containing images to scrape/catalog (default: $HOME/Images)")
	secureCookies := flag.Bool("secure-cookies", false, "mark the session cookie Secure; enable once served over TLS")
	flag.Parse()

	logger := slog.New(slog.NewJSONHandler(os.Stdout, nil))

	imageDir := *imageDirFlag
	if imageDir == "" {
		home, err := os.UserHomeDir()
		if err != nil {
			logger.Error("failed to resolve home directory", "err", err)
			os.Exit(1)
		}
		imageDir = filepath.Join(home, "Images")
	}

	if err := os.MkdirAll(imageDir, 0o755); err != nil {
		logger.Error("failed to create image directory", "dir", imageDir, "err", err)
		os.Exit(1)
	}

	session := scs.New()
	session.Lifetime = 24 * time.Hour
	session.Cookie.HttpOnly = true
	session.Cookie.SameSite = http.SameSiteLaxMode
	session.Cookie.Secure = *secureCookies

	r := chi.NewRouter()
	r.Use(middleware.Logger)
	r.Use(middleware.Recoverer)

	r.Route("/review", func(r chi.Router) {
		review.Mount(r, logger, imageDir)
	})

	r.Handle("/static/*", http.StripPrefix("/static/", http.FileServer(http.Dir("web/static"))))
	r.Handle(
		"/images/*",
		http.StripPrefix(
			"/images/",
			http.FileServer(http.Dir(imageDir)),
		),
	)

	r.Get("/", func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, "/scrape", http.StatusFound)
	})

	scraper.Mount(r, logger, session, imageDir)
	catalog.Mount(r, logger, imageDir)

	srv := &http.Server{
		Addr:              ":8080",
		Handler:           session.LoadAndSave(r),
		ReadTimeout:       15 * time.Second,
		ReadHeaderTimeout: 5 * time.Second,
		WriteTimeout:      60 * time.Second,
		IdleTimeout:       120 * time.Second,
	}

	go func() {
		logger.Info("server starting", "addr", srv.Addr)
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			logger.Error("server failed", "err", err)
			os.Exit(1)
		}
	}()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	<-stop

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	logger.Info("server shutting down")
	if err := srv.Shutdown(shutdownCtx); err != nil {
		logger.Error("graceful shutdown failed", "err", err)
	}
}
