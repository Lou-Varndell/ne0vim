document.addEventListener("keydown", function (event) {

    // Ignore typing in inputs
    if (
        event.target.tagName === "INPUT" ||
        event.target.tagName === "TEXTAREA"
    ) {
        return;
    }

    if (event.key === "ArrowRight") {

        const next = document.querySelector("#next-button");

        if (next && !next.disabled) {
            next.click();
        }
    }

    if (event.key === "ArrowLeft") {

        const prev = document.querySelector("#prev-button");

        if (prev && !prev.disabled) {
            prev.click();
        }
    }

    if (event.key === "d" || event.key === "D") {

        const del = document.querySelector("#delete-button");

        if (del && !del.disabled) {
            del.click();
        }
    }

    if (event.key === "c" || event.key === "C") {
    const td = document.getElementById("image-path");
    if (!td) return;

    copyTextToClipboard(td.dataset.path);

    event.preventDefault();
    }
});

function copyTextToClipboard(text) {
    navigator.clipboard.writeText(text)
        .then(() => {
            showStatus("Copied path");
        })
        .catch(err => {
            console.error("Failed to copy:", err);
        });
}

function copyImagePath(event, element) {
    event.preventDefault();
    copyTextToClipboard(element.dataset.path);
}

function showStatus(message) {
    const toast = document.getElementById("status-toast");

    toast.textContent = message;
    toast.style.display = "block";

    clearTimeout(showStatus.timer);

    showStatus.timer = setTimeout(() => {
        toast.style.display = "none";
    }, 1000);
}
