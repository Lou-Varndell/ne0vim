# media-manager

A small Go web app for scraping images from web pages, browsing them in a
catalog, and reviewing them for cleanup. Server-rendered with
[templ](https://templ.guide) and [htmx](https://htmx.org), styled with
[Bulma](https://bulma.io).

## Features

- **Scrape** (`/scrape`) — paste a list of page URLs, discover the images on
  each page (including `srcset`/lazy-load attributes), and download the ones
  you want into your local image directory.
- **Catalog** (`/catalog`) — browse the image directory one folder at a time,
  with breadcrumb navigation.
- **Review** (`/review`) — step through every image below a minimum
  width/height threshold, one at a time, to find small or low-quality images
  worth deleting or replacing.

Images are served from `/images/*`, backed directly by the configured image
directory.

## Requirements

- Go (see `go.mod` for the minimum version)
- [`templ`](https://templ.guide) CLI, for regenerating `*_templ.go` files
  after editing a `.templ` file:
  ```bash
  go install github.com/a-h/templ/cmd/templ@v0.3.1020
  ```
- [`air`](https://github.com/air-verse/air) (optional), for live-reload during
  development:
  ```bash
  go install github.com/air-verse/air@latest
  ```

## Getting started

```bash
make build   # vendors Bulma/htmx, generates templates, builds ./bin/server
./bin/server -image-dir ~/Images
```

Then open http://localhost:8080. If `-image-dir` is omitted, it defaults to
`$HOME/Images` and is created if it doesn't already exist.

### Development

```bash
make dev
```

Runs `templ generate --watch` alongside `air`, so editing a `.templ` file or
any `.go` file rebuilds and restarts the server automatically.

### Flags

| Flag | Default | Description |
|---|---|---|
| `-image-dir` | `$HOME/Images` | Directory to scrape into, catalog, and review. |
| `-secure-cookies` | `false` | Mark the session cookie `Secure`. Enable once the app is served over TLS. |

## Project layout

```
cmd/server/           entrypoint: flag parsing, router wiring, graceful shutdown
internal/scraper/      page scraping, image discovery, SSRF-safe downloading
internal/catalog/      directory-by-directory image browser
internal/review/       single-image review flow, filtered by minimum size
internal/reviewmodel/  view model + pagination helpers for the review flow
internal/catalogmodel/ view model for the catalog
internal/workerpool/   small bounded-concurrency helper shared by the scraper
web/templates/         templ components (.templ source + generated *_templ.go)
web/static/            vendored Bulma CSS and htmx JS, plus app.css overrides
```

Each feature package under `internal/` exposes a `Mount(r chi.Router, ...)`
function that wires its own routes onto the shared `chi.Router`, and owns its
own scanning/business logic separately from its HTTP handlers.

## The review workflow

`/review` finds every image in the configured directory whose width **or**
height falls below a `min` threshold (default 100px) and lets you step
through them one at a time — handy for spotting thumbnails, broken
placeholders, or otherwise low-value images scattered across a large
directory.

- `GET /review` — full page: the size-threshold form plus the current image.
- `GET /review/content` — just the image panel, used as the htmx swap target
  for the Previous/Next buttons so paging doesn't reload the whole page.

Both accept:

| Query param | Meaning |
|---|---|
| `min` | Minimum width/height in pixels; images smaller than this on either axis are included. Defaults to 100. |
| `current` | Index into the filtered result set to display. Clamped to a valid index automatically. |

The scan (`internal/review.Scan`) walks the image directory recursively,
decoding just enough of each file to read its dimensions
(`image.DecodeConfig`, so full images are never fully loaded into memory).
Unreadable entries — a permission-denied subdirectory, a broken symlink — are
logged and skipped rather than failing the whole scan, matching the behavior
of the catalog scanner.

The directory is rescanned on every request, so images added or removed by
the scraper mid-session are picked up without a server restart.

## Testing

```bash
make test        # go test ./...
golangci-lint run ./...
```

`internal/catalog` and `internal/review` both include scan tests covering the
happy path, non-image files being skipped (never deleted), non-directory
input, and — for review — a permission-denied subdirectory not aborting the
rest of the scan.

## Security notes

- The scraper's HTTP client resolves hostnames itself and refuses to dial
  loopback, private, link-local, multicast, or CGNAT addresses on every
  request and redirect hop, to prevent SSRF against internal infrastructure.
- Downloaded images are capped at 25 MiB and re-verified as `image/*` by
  their actual response `Content-Type`, not just the extension in the URL.
- The catalog browser confines `?dir=` to the configured image directory,
  resolving symlinks and clamping `..` traversal so requests can't escape the
  image root.
