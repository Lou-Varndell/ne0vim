# media-manager

A small Go web app for scraping images from web pages, browsing them in a
catalog, and reviewing them for cleanup. Server-rendered with
[templ](https://templ.guide) and [htmx](https://htmx.org), styled with
[Bulma](https://bulma.io).

## Features

- **Scrape** (`/scrape`) — paste a list of page URLs, discover the images on
  each page (including `srcset`/lazy-load attributes), and download the ones
  you want into your local image directory.
- **Catalog** (`/catalog`) — browse the image directory one folder at a time,
  with breadcrumb navigation.
- **Review** (`/review`) — step through every image below a minimum
  width/height threshold, one at a time, to find small or low-quality images
  worth deleting or replacing.

Images are served from `/images/*`, backed directly by the configured image
directory.

## Requirements

- Go (see `go.mod` for the minimum version)
- [`templ`](https://templ.guide) CLI, for regenerating `*_templ.go` files
  after editing a `.templ` file:
  ```bash
  go install github.com/a-h/templ/cmd/templ@v0.3.1020
  ```
- [`air`](https://github.com/air-verse/air) (optional), for live-reload during
  development:
  ```bash
  go install github.com/air-verse/air@latest
  ```

## Getting started

```bash
make build   # vendors Bulma/htmx, generates templates, builds ./bin/server
./bin/server -image-dir ~/Images
```

Then open http://localhost:8080. If `-image-dir` is omitted, it defaults to
`$HOME/Images` and is created if it doesn't already exist.

### Development

```bash
make dev
```

Runs `templ generate --watch` alongside `air`, so editing a `.templ` file or
any `.go` file rebuilds and restarts the server automatically.

### Flags

| Flag | Default | Description |
|---|---|---|
| `-image-dir` | `$HOME/Images` | Directory to scrape into, catalog, and review. |
| `-secure-cookies` | `false` | Mark the session cookie `Secure`. Enable once the app is served over TLS. |

## Project layout

```
cmd/server/           entrypoint: flag parsing, router wiring, graceful shutdown
internal/scraper/      page scraping, image discovery, SSRF-safe downloading
internal/catalog/      directory-by-directory image browser
internal/review/       single-image review flow, filtered by minimum size
internal/reviewmodel/  view model + pagination helpers for the review flow
internal/catalogmodel/ view model for the catalog
internal/workerpool/   small bounded-concurrency helper shared by the scraper
web/templates/         templ components (.templ source + generated *_templ.go)
web/static/            vendored Bulma CSS and htmx JS, plus app.css overrides and
                       review.js (hand-written keyboard navigation, see below)
```

Each feature package under `internal/` exposes a `Mount(r chi.Router, ...)`
function that wires its own routes onto the shared `chi.Router`, and owns its
own scanning/business logic separately from its HTTP handlers.

## The review workflow

`/review` finds every image in the configured directory whose width **or**
height falls below a `min` threshold (default 100px) and lets you step
through them one at a time — handy for spotting thumbnails, broken
placeholders, or otherwise low-value images scattered across a large
directory.

- `GET /review` — full page: the size-threshold form plus the current image.
- `GET /review/content` — just the image panel, used as the htmx swap target
  for the Previous/Next buttons so paging doesn't reload the whole page.

Both accept:

| Query param | Meaning |
|---|---|
| `min` | Minimum width/height in pixels; images smaller than this on either axis are included. Defaults to 100. |
| `current` | Index into the filtered result set to display. Clamped to a valid index automatically. |
| `rescan` | Set to `1` to force a fresh filesystem scan, bypassing the cached result (see below). |

The scan (`internal/review.Scan`) walks the image directory recursively,
decoding just enough of each file to read its dimensions
(`image.DecodeConfig`, so full images are never fully loaded into memory).
Unreadable entries — a permission-denied subdirectory, a broken symlink — are
logged and skipped rather than failing the whole scan, matching the behavior
of the catalog scanner.

### Scan caching

The scan result is cached in the browser session (via the same
`scs.SessionManager` the scraper uses to hold parsed image URLs), keyed
implicitly by `min`. Prev/Next requests reuse that cached result and just
index into it, so paging is in-memory rather than re-walking the filesystem
on every click. A cached result is discarded and rescanned automatically
when `min` changes, or on demand via the **Rescan** button (`?rescan=1`) if
files were added or removed on disk without changing `min`.

### Keyboard navigation

`web/static/js/review.js` listens for key presses site-wide: `←` clicks the
Previous button, `→` clicks Next, `d` clicks Delete, all by `id`
(`#prev-button` / `#next-button` / `#delete-button`), so every action goes
through the same htmx requests as a mouse click. Presses are ignored while
focus is inside an `<input>` or `<textarea>` (e.g. the `min` field), and a
click is skipped if the corresponding button is absent or `disabled`
(start/end of the result set).

### Deleting an image

Delete (via the Delete button on `/review` or the `d` key) doesn't remove a
file outright: it moves it into a `.trash` directory at the root of the
image directory, preserving its relative path. `internal/review.Scan` skips
`.trash` entirely, so trashed images never reappear in the review queue on a
later scan.

## Testing

```bash
make test        # go test ./...
golangci-lint run ./...
```

`internal/catalog` and `internal/review` both include scan tests covering the
happy path, non-image files being skipped (never deleted), non-directory
input, and — for review — a permission-denied subdirectory not aborting the
rest of the scan.

## Security notes

- The scraper's HTTP client resolves hostnames itself and refuses to dial
  loopback, private, link-local, multicast, or CGNAT addresses on every
  request and redirect hop, to prevent SSRF against internal infrastructure.
- Downloaded images are capped at 25 MiB and re-verified as `image/*` by
  their actual response `Content-Type`, not just the extension in the URL.
- The catalog browser confines `?dir=` to the configured image directory,
  resolving symlinks and clamping `..` traversal so requests can't escape the
  image root.
