// Package catalogmodel holds the plain view types shared between the catalog
// scanner (internal/catalog) and the templ components (web/templates/catalog).
// It imports neither, so it is a leaf package that both can depend on without
// forming an import cycle.
package catalogmodel

// CatalogPage is the full view model rendered by the catalog page: the
// breadcrumb trail to CurrentDir, the immediate sub-directories, and the
// images in CurrentDir.
type CatalogPage struct {
	CurrentDir  string
	Breadcrumb  []Crumb
	Directories []Directory
	Images      []Image
}

// Directory is a single navigable sub-directory of the current directory.
type Directory struct {
	Name string
	Path string
}

// Image is a single catalogued image, with its full-size and thumbnail paths
// rooted under the /images route.
type Image struct {
	Name  string
	Path  string
	Thumb string
}

// Crumb is one segment of the breadcrumb trail leading to the current
// directory.
type Crumb struct {
	Name string
	Path string
}
