package workerpool

import (
	"context"
	"sync/atomic"
	"testing"
)

func TestRun_ProcessesAllItems(t *testing.T) {
	items := []int{1, 2, 3, 4, 5}

	var sum atomic.Int64
	Run(context.Background(), 2, items, func(n int) {
		sum.Add(int64(n))
	})

	if got := sum.Load(); got != 15 {
		t.Errorf("sum = %d, want 15", got)
	}
}

func TestRun_EmptyItems(t *testing.T) {
	called := false
	Run(context.Background(), 4, []string{}, func(string) {
		called = true
	})

	if called {
		t.Error("fn should not be called for an empty slice")
	}
}

func TestRun_WorkersExceedItems(t *testing.T) {
	items := []int{1, 2}

	var count atomic.Int64
	Run(context.Background(), 100, items, func(int) {
		count.Add(1)
	})

	if got := count.Load(); got != 2 {
		t.Errorf("count = %d, want 2", got)
	}
}
