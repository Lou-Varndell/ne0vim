package workerpool

import (
	"context"
	"sync"
)

// Run fans items out across min(workers, len(items)) goroutines, calling fn
// once per item, and blocks until every enqueued item has been processed. If
// ctx is cancelled, Run stops enqueuing further items and returns once the
// in-flight ones finish; fn is still responsible for honouring ctx within a
// single item's work.
func Run[T any](ctx context.Context, workers int, items []T, fn func(T)) {
	if len(items) == 0 {
		return
	}

	if workers > len(items) {
		workers = len(items)
	}

	jobs := make(chan T)
	var wg sync.WaitGroup

	for range workers {
		wg.Go(func() {
			for item := range jobs {
				fn(item)
			}
		})
	}

	for _, item := range items {
		select {
		case jobs <- item:
		case <-ctx.Done():
			// Stop feeding new work; drain what's already running below.
			close(jobs)
			wg.Wait()
			return
		}
	}
	close(jobs)
	wg.Wait()
}
