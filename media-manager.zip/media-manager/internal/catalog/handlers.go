package catalog

import (
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	catalogtpl "media-manager/web/templates/catalog"

	"github.com/go-chi/chi/v5"
)

type handler struct {
	log      *slog.Logger
	imageDir string
}

// Mount wires the catalog routes onto r. imageDir is scanned fresh on every
// request to /catalog, so images added by the scraper mid-run are picked up
// without a server restart.
func Mount(r chi.Router, log *slog.Logger, imageDir string) {
	h := &handler{
		log:      log,
		imageDir: imageDir,
	}

	r.Get("/catalog", h.home)
}

// resolveDir confines a user-supplied ?dir value to imageDir. It returns the
// absolute filesystem path to scan, or false if the request escapes the jail.
func resolveDir(imageDir, dir string) (string, bool) {
	absRoot, err := canonicalRoot(imageDir)
	if err != nil {
		return "", false
	}

	// Prevent ".." escaping the image root.
	rel := strings.TrimPrefix(
		filepath.Clean("/"+filepath.FromSlash(dir)),
		string(os.PathSeparator),
	)

	target := filepath.Join(absRoot, rel)

	// Resolve symlinks if possible.
	if resolved, err := filepath.EvalSymlinks(target); err == nil {
		target = resolved
	}

	if target != absRoot &&
		!strings.HasPrefix(target, absRoot+string(os.PathSeparator)) {
		return "", false
	}

	return target, true
}

// canonicalRoot returns the absolute, symlink-resolved form of imageDir.
func canonicalRoot(imageDir string) (string, error) {
	absRoot, err := filepath.Abs(imageDir)
	if err != nil {
		return "", err
	}

	if resolved, err := filepath.EvalSymlinks(absRoot); err == nil {
		return resolved, nil
	}

	return absRoot, nil
}

func (h *handler) home(w http.ResponseWriter, r *http.Request) {
	absRoot, err := canonicalRoot(h.imageDir)
	if err != nil {
		h.log.Error("resolve image dir failed", "err", err)
		http.Error(w, "server misconfiguration", http.StatusInternalServerError)
		return
	}

	target, ok := resolveDir(h.imageDir, r.URL.Query().Get("dir"))
	if !ok {
		http.Error(w, "invalid directory", http.StatusBadRequest)
		return
	}

	page, err := ScanCatalog(absRoot, target, h.log)
	if err != nil {
		h.log.Error("scan catalog failed", "dir", target, "err", err)
		http.Error(w, "failed to scan directory", http.StatusInternalServerError)
		return
	}

	// HTMX requests only receive the catalog fragment.
	if r.Header.Get("HX-Request") == "true" {
		if err := catalogtpl.CatalogContent(page).Render(r.Context(), w); err != nil {
			h.log.Error("render catalog content failed", "err", err)
		}
		return
	}

	// Normal browser request gets the full page.
	if err := catalogtpl.Catalog(page).Render(r.Context(), w); err != nil {
		h.log.Error("render catalog page failed", "err", err)
	}
}
