package catalog

import (
	"image"
	"image/color"
	"image/png"
	"log/slog"
	"os"
	"path/filepath"
	"testing"
)

func TestIsText(t *testing.T) {
	cases := []struct {
		mime string
		want bool
	}{
		{"text/plain; charset=utf-8", true},
		{"application/json", true},
		{"application/xml", true},
		{"application/javascript", true},
		{"application/x-yaml", true},
		{"application/yaml", true},
		{"image/png", false},
		{"image/jpeg", false},
		{"application/octet-stream", false},
	}

	for _, c := range cases {
		if got := isText(c.mime); got != c.want {
			t.Errorf("isText(%q) = %v, want %v", c.mime, got, c.want)
		}
	}
}

func writePNG(t *testing.T, path string, width, height int) {
	t.Helper()

	img := image.NewRGBA(image.Rect(0, 0, width, height))
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			img.Set(x, y, color.White)
		}
	}

	f, err := os.Create(path)
	if err != nil {
		t.Fatalf("create %s: %v", path, err)
	}
	defer f.Close()

	if err := png.Encode(f, img); err != nil {
		t.Fatalf("encode png %s: %v", path, err)
	}
}

func quietLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelError + 1}))
}

func TestScanImages_IncludesAllSizes(t *testing.T) {
	dir := t.TempDir()

	writePNG(t, filepath.Join(dir, "small.png"), 100, 100)
	writePNG(t, filepath.Join(dir, "large.png"), 400, 400)

	images, err := ScanImages(dir, quietLogger())
	if err != nil {
		t.Fatalf("ScanImages: %v", err)
	}

	if len(images) != 2 {
		t.Fatalf("got %d images, want 2: %v", len(images), images)
	}

	// Paths are URL paths, always slash-separated regardless of platform.
	want := map[string]bool{
		"images/small.png": true,
		"images/large.png": true,
	}
	for _, img := range images {
		if !want[img] {
			t.Errorf("unexpected image path %q", img)
		}
		delete(want, img)
	}
	if len(want) != 0 {
		t.Errorf("missing expected images: %v", want)
	}
}

// TestScanImages_SkipsButKeepsNonImages guards the security fix: scanning is
// read-only, so text files and .DS_Store are excluded from the result but must
// never be deleted from disk.
func TestScanImages_SkipsButKeepsNonImages(t *testing.T) {
	dir := t.TempDir()

	textPath := filepath.Join(dir, "notes.txt")
	if err := os.WriteFile(textPath, []byte("hello world"), 0o644); err != nil {
		t.Fatalf("write text file: %v", err)
	}

	dsStorePath := filepath.Join(dir, ".DS_Store")
	if err := os.WriteFile(dsStorePath, []byte("junk"), 0o644); err != nil {
		t.Fatalf("write .DS_Store: %v", err)
	}

	writePNG(t, filepath.Join(dir, "small.png"), 100, 100)

	images, err := ScanImages(dir, quietLogger())
	if err != nil {
		t.Fatalf("ScanImages: %v", err)
	}

	if len(images) != 1 {
		t.Fatalf("got %d images, want 1: %v", len(images), images)
	}

	if _, err := os.Stat(textPath); err != nil {
		t.Errorf("notes.txt must not be removed by a scan, stat err = %v", err)
	}
	if _, err := os.Stat(dsStorePath); err != nil {
		t.Errorf(".DS_Store must not be removed by a scan, stat err = %v", err)
	}
}

func TestScanImages_RejectsNonDirectory(t *testing.T) {
	dir := t.TempDir()
	filePath := filepath.Join(dir, "not-a-dir")
	if err := os.WriteFile(filePath, []byte("x"), 0o644); err != nil {
		t.Fatalf("write file: %v", err)
	}

	if _, err := ScanImages(filePath, quietLogger()); err == nil {
		t.Error("expected error for non-directory imageDir, got nil")
	}
}

// TestScanCatalog_ListsOneLevel verifies ScanCatalog returns only the
// immediate directory contents, with slash-separated relative paths and a
// breadcrumb trail.
func TestScanCatalog_ListsOneLevel(t *testing.T) {
	root := t.TempDir()

	writePNG(t, filepath.Join(root, "top.png"), 50, 50)
	sub := filepath.Join(root, "sub")
	if err := os.Mkdir(sub, 0o755); err != nil {
		t.Fatalf("mkdir sub: %v", err)
	}
	writePNG(t, filepath.Join(sub, "nested.png"), 50, 50)

	page, err := ScanCatalog(root, root, quietLogger())
	if err != nil {
		t.Fatalf("ScanCatalog: %v", err)
	}

	if len(page.Images) != 1 || page.Images[0].Name != "top.png" {
		t.Errorf("root images = %+v, want just top.png", page.Images)
	}
	if page.Images[0].Path != "images/top.png" {
		t.Errorf("image path = %q, want images/top.png", page.Images[0].Path)
	}
	if len(page.Directories) != 1 || page.Directories[0].Name != "sub" {
		t.Errorf("directories = %+v, want just sub", page.Directories)
	}
	if page.Directories[0].Path != "sub" {
		t.Errorf("dir path = %q, want sub", page.Directories[0].Path)
	}
	if len(page.Breadcrumb) != 1 || page.Breadcrumb[0].Name != "Home" {
		t.Errorf("breadcrumb = %+v, want just Home", page.Breadcrumb)
	}
}

func TestResolveDir(t *testing.T) {
	root := t.TempDir()
	sub := filepath.Join(root, "sub")
	if err := os.Mkdir(sub, 0o755); err != nil {
		t.Fatalf("mkdir sub: %v", err)
	}

	absRoot, err := filepath.EvalSymlinks(root)
	if err != nil {
		t.Fatalf("resolve root: %v", err)
	}

	cases := []struct {
		name   string
		dir    string
		want   string
		wantOK bool
	}{
		{"empty resolves to root", "", absRoot, true},
		{"sub resolves under root", "sub", filepath.Join(absRoot, "sub"), true},
		// ".." segments are clamped at the root, so this lands at root/etc
		// (inside the jail), never at the real /etc.
		{"dot-dot cannot escape", "../../../etc", filepath.Join(absRoot, "etc"), true},
		{"leading slash is treated relative", "/sub", filepath.Join(absRoot, "sub"), true},
		{"deep traversal is clamped", "sub/../../..", absRoot, true},
	}

	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got, ok := resolveDir(root, c.dir)
			if ok != c.wantOK {
				t.Fatalf("resolveDir(%q) ok = %v, want %v", c.dir, ok, c.wantOK)
			}
			if ok && got != c.want {
				t.Errorf("resolveDir(%q) = %q, want %q", c.dir, got, c.want)
			}
		})
	}
}
