package reviewmodel

import "fmt"

type Page struct {
	Result

	Current int
}

func (p Page) HasImages() bool {
	return len(p.Images) > 0
}

func (p Page) Image() Image {
	return p.Images[p.Current]
}

func (p Page) Count() int {
	return len(p.Images)
}

func (p Page) HasPrev() bool {
	return p.Current > 0
}

func (p Page) HasNext() bool {
	return p.Current < len(p.Images)-1
}

func (p Page) Prev() int {
	if p.HasPrev() {
		return p.Current - 1
	}
	return p.Current
}

func (p Page) Next() int {
	if p.HasNext() {
		return p.Current + 1
	}
	return p.Current
}

func (p Page) PrevURL() string {
	return fmt.Sprintf(
		"/review/content?current=%d&min=%d",
		p.Prev(),
		p.MinSize,
	)
}

func (p Page) NextURL() string {
	return fmt.Sprintf(
		"/review/content?current=%d&min=%d",
		p.Next(),
		p.MinSize,
	)
}

func (p Page) Position() int {
	if !p.HasImages() {
		return 0
	}
	return p.Current + 1
}
