package reviewmodel

type Image struct {
	Path   string
	URL    string
	Name   string
	Format string

	Width  int
	Height int
	Size   int64
}

type Result struct {
	Images  []Image
	Root    string
	MinSize int
}
