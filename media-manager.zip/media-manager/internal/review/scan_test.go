package review

import (
	"image"
	"image/color"
	"image/png"
	"log/slog"
	"os"
	"path/filepath"
	"testing"
)

func writePNG(t *testing.T, path string, width, height int) {
	t.Helper()

	img := image.NewRGBA(image.Rect(0, 0, width, height))
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			img.Set(x, y, color.White)
		}
	}

	f, err := os.Create(path)
	if err != nil {
		t.Fatalf("create %s: %v", path, err)
	}
	defer f.Close()

	if err := png.Encode(f, img); err != nil {
		t.Fatalf("encode png %s: %v", path, err)
	}
}

func quietLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelError + 1}))
}

func TestScan_ReturnsOnlyImagesBelowMinSize(t *testing.T) {
	dir := t.TempDir()

	writePNG(t, filepath.Join(dir, "small.png"), 50, 50)
	writePNG(t, filepath.Join(dir, "large.png"), 400, 400)

	result, err := Scan(dir, 100, quietLogger())
	if err != nil {
		t.Fatalf("Scan: %v", err)
	}

	if len(result.Images) != 1 || result.Images[0].Name != "small.png" {
		t.Fatalf("images = %+v, want just small.png", result.Images)
	}
	if result.Images[0].URL != "/images/small.png" {
		t.Errorf("URL = %q, want /images/small.png", result.Images[0].URL)
	}
	if result.Images[0].Width != 50 || result.Images[0].Height != 50 {
		t.Errorf("dimensions = %dx%d, want 50x50", result.Images[0].Width, result.Images[0].Height)
	}
}

func TestScan_SkipsNonImages(t *testing.T) {
	dir := t.TempDir()

	if err := os.WriteFile(filepath.Join(dir, "notes.txt"), []byte("hello"), 0o644); err != nil {
		t.Fatalf("write text file: %v", err)
	}
	writePNG(t, filepath.Join(dir, "small.png"), 50, 50)

	result, err := Scan(dir, 100, quietLogger())
	if err != nil {
		t.Fatalf("Scan: %v", err)
	}

	if len(result.Images) != 1 || result.Images[0].Name != "small.png" {
		t.Fatalf("images = %+v, want just small.png", result.Images)
	}
}

// TestScan_SkipsTrashDir guards against trashed images (moved into
// root/.trash by the delete flow) being picked back up by a later scan and
// reappearing in the review queue.
func TestScan_SkipsTrashDir(t *testing.T) {
	dir := t.TempDir()

	writePNG(t, filepath.Join(dir, "visible.png"), 50, 50)

	trashDir := filepath.Join(dir, trashDirName)
	if err := os.Mkdir(trashDir, 0o755); err != nil {
		t.Fatalf("mkdir trash dir: %v", err)
	}
	writePNG(t, filepath.Join(trashDir, "trashed.png"), 50, 50)

	result, err := Scan(dir, 100, quietLogger())
	if err != nil {
		t.Fatalf("Scan: %v", err)
	}

	if len(result.Images) != 1 || result.Images[0].Name != "visible.png" {
		t.Fatalf("images = %+v, want just visible.png", result.Images)
	}
}

// TestScan_ContinuesPastUnreadableSubdir guards against one bad entry
// (permission-denied directory, broken symlink, etc.) aborting the whole
// walk: a sibling file below min size must still be found and returned.
func TestScan_ContinuesPastUnreadableSubdir(t *testing.T) {
	if os.Getuid() == 0 {
		t.Skip("root ignores directory permissions, cannot simulate denial")
	}

	dir := t.TempDir()

	locked := filepath.Join(dir, "locked")
	if err := os.Mkdir(locked, 0o755); err != nil {
		t.Fatalf("mkdir locked: %v", err)
	}
	writePNG(t, filepath.Join(locked, "hidden.png"), 50, 50)
	if err := os.Chmod(locked, 0o000); err != nil {
		t.Fatalf("chmod locked: %v", err)
	}
	t.Cleanup(func() { os.Chmod(locked, 0o755) })

	writePNG(t, filepath.Join(dir, "visible.png"), 50, 50)

	result, err := Scan(dir, 100, quietLogger())
	if err != nil {
		t.Fatalf("Scan: %v, want nil (unreadable entries should be skipped, not fail the walk)", err)
	}

	if len(result.Images) != 1 || result.Images[0].Name != "visible.png" {
		t.Fatalf("images = %+v, want just visible.png", result.Images)
	}
}

func TestScan_RejectsNonDirectory(t *testing.T) {
	dir := t.TempDir()
	filePath := filepath.Join(dir, "not-a-dir")
	if err := os.WriteFile(filePath, []byte("x"), 0o644); err != nil {
		t.Fatalf("write file: %v", err)
	}

	if _, err := Scan(filePath, 100, quietLogger()); err == nil {
		t.Error("expected error for non-directory root, got nil")
	}
}

func TestScan_MissingRoot(t *testing.T) {
	if _, err := Scan(filepath.Join(t.TempDir(), "missing"), 100, quietLogger()); err == nil {
		t.Error("expected error for missing root, got nil")
	}
}
