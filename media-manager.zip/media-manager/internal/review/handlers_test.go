package review

import (
	"io"
	"net/http"
	"net/http/cookiejar"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/alexedwards/scs/v2"
	"github.com/go-chi/chi/v5"
)

// newTestServer wires review's routes behind a real scs session, so caching
// behavior can be exercised the same way it runs in production: the session
// cookie set by the first request must be sent on the second for the cache
// to be found.
func newTestServer(t *testing.T, imageDir string) (*httptest.Server, *http.Client) {
	t.Helper()

	session := scs.New()
	session.Lifetime = time.Hour

	r := chi.NewRouter()
	r.Route("/review", func(r chi.Router) {
		Mount(r, quietLogger(), session, imageDir)
	})

	srv := httptest.NewServer(session.LoadAndSave(r))
	t.Cleanup(srv.Close)

	jar, err := cookiejar.New(nil)
	if err != nil {
		t.Fatalf("cookiejar.New: %v", err)
	}

	return srv, &http.Client{Jar: jar}
}

func getBody(t *testing.T, client *http.Client, url string) string {
	t.Helper()

	resp, err := client.Get(url)
	if err != nil {
		t.Fatalf("GET %s: %v", url, err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("read body: %v", err)
	}

	if resp.StatusCode != http.StatusOK {
		t.Fatalf("GET %s: status = %d, body = %s", url, resp.StatusCode, body)
	}

	return string(body)
}

func postBody(t *testing.T, client *http.Client, url string) string {
	t.Helper()

	resp, err := client.Post(url, "application/x-www-form-urlencoded", nil)
	if err != nil {
		t.Fatalf("POST %s: %v", url, err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("read body: %v", err)
	}

	if resp.StatusCode != http.StatusOK {
		t.Fatalf("POST %s: status = %d, body = %s", url, resp.StatusCode, body)
	}

	return string(body)
}

func TestContent_ReusesCachedScan_SameMin(t *testing.T) {
	dir := t.TempDir()
	writePNG(t, filepath.Join(dir, "small.png"), 50, 50)

	srv, client := newTestServer(t, dir)

	// First request scans the directory and caches the result in-session.
	body := getBody(t, client, srv.URL+"/review?min=100")
	if !strings.Contains(body, "small.png") {
		t.Fatalf("initial scan missing small.png:\n%s", body)
	}

	// Remove the file from disk without changing min. A cached result
	// should still be served, so small.png keeps appearing.
	if err := os.Remove(filepath.Join(dir, "small.png")); err != nil {
		t.Fatalf("remove small.png: %v", err)
	}

	body = getBody(t, client, srv.URL+"/review/content?min=100&current=0")
	if !strings.Contains(body, "small.png") {
		t.Fatalf("expected cached small.png to still be served after deletion, got:\n%s", body)
	}
}

func TestContent_RescansOnMinChange(t *testing.T) {
	dir := t.TempDir()
	writePNG(t, filepath.Join(dir, "small.png"), 50, 50)

	srv, client := newTestServer(t, dir)

	// Cache a scan result under min=100.
	getBody(t, client, srv.URL+"/review?min=100")

	if err := os.Remove(filepath.Join(dir, "small.png")); err != nil {
		t.Fatalf("remove small.png: %v", err)
	}

	// A different min must not reuse the min=100 cache entry.
	body := getBody(t, client, srv.URL+"/review/content?min=200&current=0")
	if strings.Contains(body, "small.png") {
		t.Fatalf("expected min change to trigger a rescan and drop deleted small.png, got:\n%s", body)
	}
}

func TestDelete_MovesImageToTrashAndAdvances(t *testing.T) {
	dir := t.TempDir()
	writePNG(t, filepath.Join(dir, "a.png"), 50, 50)
	writePNG(t, filepath.Join(dir, "b.png"), 50, 50)

	srv, client := newTestServer(t, dir)

	// Cache the scan; the first image shown (in walk order) is a.png.
	body := getBody(t, client, srv.URL+"/review?min=100")
	if !strings.Contains(body, "a.png") {
		t.Fatalf("initial scan expected to show a.png first:\n%s", body)
	}

	// Delete the image at index 0 (a.png).
	body = postBody(t, client, srv.URL+"/review/delete?min=100&current=0")

	if strings.Contains(body, "a.png") {
		t.Fatalf("expected a.png removed from the page after delete, got:\n%s", body)
	}
	if !strings.Contains(body, "b.png") {
		t.Fatalf("expected b.png still shown after deleting a.png, got:\n%s", body)
	}

	if _, err := os.Stat(filepath.Join(dir, "a.png")); !os.IsNotExist(err) {
		t.Fatalf("expected a.png removed from its original location, stat err = %v", err)
	}
	if _, err := os.Stat(filepath.Join(dir, trashDirName, "a.png")); err != nil {
		t.Fatalf("expected a.png moved into trash, stat err = %v", err)
	}

	// A later request against the same cached session must not see a.png
	// again (the in-session cache should have been updated, not just the
	// response for this one request).
	body = getBody(t, client, srv.URL+"/review/content?min=100&current=0")
	if strings.Contains(body, "a.png") {
		t.Fatalf("expected cached session to drop deleted a.png, got:\n%s", body)
	}
}

func TestContent_RescanParamForcesFreshScan(t *testing.T) {
	dir := t.TempDir()
	writePNG(t, filepath.Join(dir, "small.png"), 50, 50)

	srv, client := newTestServer(t, dir)

	// Cache a scan result under min=100.
	getBody(t, client, srv.URL+"/review?min=100")

	if err := os.Remove(filepath.Join(dir, "small.png")); err != nil {
		t.Fatalf("remove small.png: %v", err)
	}

	// Same min as the cached entry, so without an explicit rescan the
	// cache would still be reused and the deletion missed.
	body := getBody(t, client, srv.URL+"/review/content?min=100&current=0&rescan=1")
	if strings.Contains(body, "small.png") {
		t.Fatalf("expected rescan=1 to force a fresh scan and drop deleted small.png, got:\n%s", body)
	}
}
