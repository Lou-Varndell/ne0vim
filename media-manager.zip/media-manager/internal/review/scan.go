package review

import (
	"image"
	"os"
	"path/filepath"

	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
	reviewmodel "media-manager/internal/reviewmodel"

	_ "golang.org/x/image/webp"
)

func imageInfo(path string) (string, int, int, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", 0, 0, err
	}
	defer f.Close()

	cfg, format, err := image.DecodeConfig(f)
	if err != nil {
		return "", 0, 0, err
	}

	return format, cfg.Width, cfg.Height, nil
}

func Scan(root string, min int) (reviewmodel.Result, error) {
	res := reviewmodel.Result{
		Root:    root,
		MinSize: min,
	}

	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}

		if d.IsDir() {
			return nil
		}

		format, w, h, err := imageInfo(path)
		if err != nil {
			return nil
		}

		if w >= min && h >= min {
			return nil
		}

		info, err := d.Info()
		if err != nil {
			return err
		}

		rel, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}

		img := reviewmodel.Image{
			Path:   path,
			URL:    "/images/" + filepath.ToSlash(rel),
			Name:   filepath.Base(path),
			Format: format,
			Width:  w,
			Height: h,
			Size:   info.Size(),
		}

		res.Images = append(res.Images, img)

		return nil
	})

	return res, err
}
