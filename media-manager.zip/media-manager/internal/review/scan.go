package review

import (
	"fmt"
	"image"
	"log/slog"
	"os"
	"path/filepath"

	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
	reviewmodel "media-manager/internal/reviewmodel"

	_ "golang.org/x/image/webp"
)

func imageInfo(path string) (string, int, int, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", 0, 0, err
	}
	defer f.Close()

	cfg, format, err := image.DecodeConfig(f)
	if err != nil {
		return "", 0, 0, err
	}

	return format, cfg.Width, cfg.Height, nil
}

// Scan walks root looking for images smaller than min on either dimension.
// Like catalog.ScanImages, unreadable entries (a permission-denied
// subdirectory, a broken symlink) are logged and skipped rather than
// aborting the whole walk, so one bad file doesn't take down the review page.
func Scan(root string, min int, log *slog.Logger) (reviewmodel.Result, error) {
	res := reviewmodel.Result{
		Root:    root,
		MinSize: min,
	}

	if info, err := os.Stat(root); err != nil {
		return res, fmt.Errorf("access image directory: %w", err)
	} else if !info.IsDir() {
		return res, fmt.Errorf("image directory is not a directory: %s", root)
	}

	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			log.Error("error accessing file", "path", path, "err", err)
			return nil
		}

		if d.IsDir() {
			return nil
		}

		format, w, h, err := imageInfo(path)
		if err != nil {
			return nil
		}

		if w >= min && h >= min {
			return nil
		}

		info, err := d.Info()
		if err != nil {
			log.Error("failed to get file info", "path", path, "err", err)
			return nil
		}

		rel, err := filepath.Rel(root, path)
		if err != nil {
			log.Error("failed to get rel", "path", path, "err", err)
			return nil
		}

		img := reviewmodel.Image{
			Path:   path,
			URL:    "/images/" + filepath.ToSlash(rel),
			Name:   filepath.Base(path),
			Format: format,
			Width:  w,
			Height: h,
			Size:   info.Size(),
		}

		res.Images = append(res.Images, img)

		return nil
	})

	return res, err
}
