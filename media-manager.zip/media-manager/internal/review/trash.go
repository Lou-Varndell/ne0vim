package review

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// trashDirName is the subdirectory under an image root that trashImage moves
// deleted images into, preserving their original relative path.
const trashDirName = ".trash"

// trashImage moves src (an absolute path inside root) into root/.trash,
// preserving its path relative to root, rather than deleting it outright.
func trashImage(root, src string) error {
	rel, err := filepath.Rel(root, src)
	if err != nil {
		return fmt.Errorf("resolve relative path: %w", err)
	}
	if rel == ".." || strings.HasPrefix(rel, ".."+string(os.PathSeparator)) {
		return fmt.Errorf("refusing to trash path outside root: %s", src)
	}

	dest := filepath.Join(root, trashDirName, rel)

	if err := os.MkdirAll(filepath.Dir(dest), 0o755); err != nil {
		return fmt.Errorf("create trash dir: %w", err)
	}

	if err := os.Rename(src, dest); err != nil {
		return fmt.Errorf("move to trash: %w", err)
	}

	return nil
}
