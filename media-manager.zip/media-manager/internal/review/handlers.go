package review

import (
	"encoding/gob"
	"log/slog"
	"net/http"
	"strconv"

	reviewmodel "media-manager/internal/reviewmodel"
	reviewtpl "media-manager/web/templates/review"

	"github.com/alexedwards/scs/v2"
	"github.com/go-chi/chi/v5"
)

const sessionKeyResult = "review:result"

func init() {
	gob.Register(reviewmodel.Result{})
}

type handler struct {
	log      *slog.Logger
	session  *scs.SessionManager
	imageDir string
}

func Mount(r chi.Router, log *slog.Logger, session *scs.SessionManager, imageDir string) {
	h := &handler{
		log:      log,
		session:  session,
		imageDir: imageDir,
	}

	r.Get("/", h.home)
	r.Get("/content", h.content)
	r.Post("/delete", h.delete)
}

func (h *handler) home(w http.ResponseWriter, r *http.Request) {
	page, err := h.loadPage(r)
	if err != nil {
		h.log.Error("scan failed", "err", err)
		http.Error(w, "scan failed", http.StatusInternalServerError)
		return
	}

	if err := reviewtpl.Review(page).Render(r.Context(), w); err != nil {
		h.log.Error("render failed", "err", err)
	}
}

func (h *handler) loadPage(r *http.Request) (reviewmodel.Page, error) {
	min := 100

	if s := r.URL.Query().Get("min"); s != "" {
		if v, err := strconv.Atoi(s); err == nil && v > 0 {
			min = v
		}
	}

	current := 0

	if s := r.URL.Query().Get("current"); s != "" {
		if v, err := strconv.Atoi(s); err == nil && v >= 0 {
			current = v
		}
	}

	result, err := h.scan(r, min)
	if err != nil {
		return reviewmodel.Page{}, err
	}

	if len(result.Images) == 0 {
		current = 0
	} else if current >= len(result.Images) {
		current = len(result.Images) - 1
	}

	return reviewmodel.Page{
		Result:  result,
		Current: current,
	}, nil
}

// scan returns the cached scan result for min if one exists in the session,
// rescanning the image directory and re-caching only when no cached result
// exists yet, it was scanned with a different min threshold, or the caller
// passed ?rescan=1 to force a fresh scan (e.g. after adding/removing files
// on disk without changing min). This keeps Prev/Next navigation to pure
// in-memory indexing instead of a filesystem walk on every request.
func (h *handler) scan(r *http.Request, min int) (reviewmodel.Result, error) {
	forced := r.URL.Query().Get("rescan") == "1"

	if !forced {
		if cached, ok := h.session.Get(r.Context(), sessionKeyResult).(reviewmodel.Result); ok && cached.MinSize == min {
			return cached, nil
		}
	}

	result, err := Scan(h.imageDir, min, h.log)
	if err != nil {
		return reviewmodel.Result{}, err
	}

	h.session.Put(r.Context(), sessionKeyResult, result)

	return result, nil
}

// delete moves the image at ?current out of the image directory into
// root/.trash (see trashImage), then re-renders the review panel at the same
// index so the next image in the (now shorter) list takes its place. The
// session's cached scan result is updated in place rather than invalidated,
// so this stays a pure in-memory operation like Prev/Next.
func (h *handler) delete(w http.ResponseWriter, r *http.Request) {
	page, err := h.loadPage(r)
	if err != nil {
		h.log.Error("scan failed", "err", err)
		http.Error(w, "scan failed", http.StatusInternalServerError)
		return
	}

	if page.HasImages() {
		img := page.Image()

		if err := trashImage(page.Root, img.Path); err != nil {
			h.log.Error("trash image failed", "path", img.Path, "err", err)
			http.Error(w, "delete failed", http.StatusInternalServerError)
			return
		}

		page.Images = append(page.Images[:page.Current], page.Images[page.Current+1:]...)
		if page.Current >= len(page.Images) && page.Current > 0 {
			page.Current--
		}

		h.session.Put(r.Context(), sessionKeyResult, page.Result)
	}

	if err := reviewtpl.ReviewContent(page).Render(r.Context(), w); err != nil {
		h.log.Error("render failed", "err", err)
	}
}

func (h *handler) content(w http.ResponseWriter, r *http.Request) {
	page, err := h.loadPage(r)
	if err != nil {
		h.log.Error("scan failed", "err", err)
		http.Error(w, "scan failed", http.StatusInternalServerError)
		return
	}

	err = reviewtpl.ReviewContent(page).Render(r.Context(), w)
	if err != nil {
		h.log.Error("render failed", "err", err)
	}
}
