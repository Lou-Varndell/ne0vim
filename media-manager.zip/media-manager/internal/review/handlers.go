package review

import (
	"log/slog"
	"net/http"
	"strconv"

	reviewmodel "media-manager/internal/reviewmodel"
	reviewtpl "media-manager/web/templates/review"

	"github.com/go-chi/chi/v5"
)

type handler struct {
	log      *slog.Logger
	imageDir string
}

func Mount(r chi.Router, log *slog.Logger, imageDir string) {
	h := &handler{
		log:      log,
		imageDir: imageDir,
	}

	r.Get("/", h.home)
	r.Get("/content", h.content)
}

func (h *handler) home(w http.ResponseWriter, r *http.Request) {
	page, err := h.loadPage(r)
	if err != nil {
		h.log.Error("scan failed", "err", err)
		http.Error(w, "scan failed", http.StatusInternalServerError)
		return
	}

	if err := reviewtpl.Review(page).Render(r.Context(), w); err != nil {
		h.log.Error("render failed", "err", err)
	}
}

func (h *handler) loadPage(r *http.Request) (reviewmodel.Page, error) {
	min := 100

	if s := r.URL.Query().Get("min"); s != "" {
		if v, err := strconv.Atoi(s); err == nil && v > 0 {
			min = v
		}
	}

	current := 0

	if s := r.URL.Query().Get("current"); s != "" {
		if v, err := strconv.Atoi(s); err == nil && v >= 0 {
			current = v
		}
	}

	result, err := Scan(h.imageDir, min, h.log)
	if err != nil {
		return reviewmodel.Page{}, err
	}

	if len(result.Images) == 0 {
		current = 0
	} else if current >= len(result.Images) {
		current = len(result.Images) - 1
	}

	return reviewmodel.Page{
		Result:  result,
		Current: current,
	}, nil
}

func (h *handler) content(w http.ResponseWriter, r *http.Request) {
	page, err := h.loadPage(r)
	if err != nil {
		h.log.Error("scan failed", "err", err)
		http.Error(w, "scan failed", http.StatusInternalServerError)
		return
	}

	err = reviewtpl.ReviewContent(page).Render(r.Context(), w)
	if err != nil {
		h.log.Error("render failed", "err", err)
	}
}
