package review

import (
	"os"
	"path/filepath"
	"testing"
)

func TestTrashImage_MovesFileIntoTrashSubdir(t *testing.T) {
	dir := t.TempDir()

	src := filepath.Join(dir, "sub", "pic.png")
	if err := os.MkdirAll(filepath.Dir(src), 0o755); err != nil {
		t.Fatalf("mkdir sub: %v", err)
	}
	writePNG(t, src, 50, 50)

	if err := trashImage(dir, src); err != nil {
		t.Fatalf("trashImage: %v", err)
	}

	if _, err := os.Stat(src); !os.IsNotExist(err) {
		t.Fatalf("expected original file gone, stat err = %v", err)
	}

	dest := filepath.Join(dir, trashDirName, "sub", "pic.png")
	if _, err := os.Stat(dest); err != nil {
		t.Fatalf("expected trashed file at %s, stat err = %v", dest, err)
	}
}
