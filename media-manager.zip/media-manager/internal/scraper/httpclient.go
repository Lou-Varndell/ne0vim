package scraper

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"time"
)

const (
	dialTimeout = 10 * time.Second
	readTimeout = 60 * time.Second
	poolWorkers = 8
	userAgent   = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) " +
		"AppleWebKit/537.36 (KHTML, like Gecko) " +
		"Chrome/148.0.0.0 Safari/537.36"

	maxFormBytes  = 1 << 20  // 1 MiB submitted text payload
	maxLines      = 200      // max URLs processed per submission
	maxImageBytes = 25 << 20 // 25 MiB per downloaded image
)

// newHTTPClient builds an *http.Client whose transport is safe to share
// across requests: safeDialContext holds no per-request state, so a single
// client can be created once and reused, preserving connection pooling.
func newHTTPClient() *http.Client {
	return &http.Client{
		Timeout: readTimeout,
		Transport: &http.Transport{
			DialContext:         safeDialContext,
			MaxIdleConns:        poolWorkers,
			MaxIdleConnsPerHost: poolWorkers,
			IdleConnTimeout:     30 * time.Second,
		},
	}
}

// cgnatRange is the RFC 6598 carrier-grade NAT / shared address space
// (100.64.0.0/10). It is not covered by net.IP.IsPrivate but is routinely
// used for internal infrastructure, so it must be blocked for SSRF safety.
var cgnatRange = &net.IPNet{
	IP:   net.IPv4(100, 64, 0, 0),
	Mask: net.CIDRMask(10, 32),
}

func isBlockedIP(ip net.IP) bool {
	return ip.IsLoopback() ||
		ip.IsPrivate() ||
		ip.IsLinkLocalUnicast() ||
		ip.IsLinkLocalMulticast() ||
		ip.IsUnspecified() ||
		ip.IsMulticast() ||
		cgnatRange.Contains(ip)
}

// safeDialContext resolves the host itself and dials only IPs that pass
// isBlockedIP, so a hostname can't be swapped to a private address between
// validation and connection (DNS rebinding), and every redirect hop is
// covered the same way since redirects re-invoke DialContext.
func safeDialContext(ctx context.Context, network, addr string) (net.Conn, error) {
	host, port, err := net.SplitHostPort(addr)
	if err != nil {
		return nil, fmt.Errorf("split host port %s: %w", addr, err)
	}

	ips, err := net.DefaultResolver.LookupIPAddr(ctx, host)
	if err != nil {
		return nil, fmt.Errorf("resolve %s: %w", host, err)
	}

	dialer := &net.Dialer{Timeout: dialTimeout}

	var lastErr error
	for _, ip := range ips {
		if isBlockedIP(ip.IP) {
			lastErr = fmt.Errorf("blocked address: %s", ip.IP)
			continue
		}

		conn, err := dialer.DialContext(ctx, network, net.JoinHostPort(ip.IP.String(), port))
		if err == nil {
			return conn, nil
		}
		lastErr = err
	}

	if lastErr == nil {
		lastErr = fmt.Errorf("no addresses found for %s", host)
	}
	return nil, lastErr
}

func newRequest(ctx context.Context, method, rawURL string) (*http.Request, error) {
	req, err := http.NewRequestWithContext(ctx, method, rawURL, nil)
	if err != nil {
		return nil, err
	}

	req.Header.Set("User-Agent", userAgent)

	return req, nil
}
