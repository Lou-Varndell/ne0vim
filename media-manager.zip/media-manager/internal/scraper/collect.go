package scraper

import (
	"context"
	"fmt"
	"net/http"
	"net/url"
	"strconv"
	"strings"

	"github.com/PuerkitoBio/goquery"
)

// collectImagesFromPage fetches rawURL and returns every image URL found on
// the page that also passed the image-content-type check.
func collectImagesFromPage(ctx context.Context, session *http.Client, rawURL string) ([]string, error) {
	req, err := newRequest(ctx, http.MethodGet, rawURL)
	if err != nil {
		return nil, fmt.Errorf("build request for %s: %w", rawURL, err)
	}

	resp, err := session.Do(req)
	if err != nil {
		return nil, fmt.Errorf("fetch %s: %w", rawURL, err)
	}
	defer resp.Body.Close()

	base := resp.Request.URL

	doc, err := goquery.NewDocumentFromReader(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("parse HTML for %s: %w", rawURL, err)
	}

	var images []string

	doc.Find("img").Each(func(_ int, s *goquery.Selection) {
		img, ok := imageURL(base, s)
		if !ok {
			return
		}

		target := img
		if a, ok := findParentAnchor(s); ok {
			href, ok := a.Attr("href")
			if !ok {
				return
			}
			resolved, ok := resolveURL(base, href)
			if !ok {
				return
			}
			target = resolved
		}

		if isImageURL(ctx, session, target) {
			images = append(images, target)
		}
	})

	return images, nil
}

func isImageURL(ctx context.Context, session *http.Client, rawURL string) bool {
	req, err := newRequest(ctx, http.MethodHead, rawURL)
	if err != nil {
		return false
	}

	resp, err := session.Do(req)
	if err != nil {
		return false
	}
	defer resp.Body.Close()

	return strings.HasPrefix(resp.Header.Get("Content-Type"), "image/")
}

func findParentAnchor(s *goquery.Selection) (*goquery.Selection, bool) {
	for p := s.Parent(); p.Length() > 0; p = p.Parent() {
		if goquery.NodeName(p) == "a" {
			return p, true
		}
	}
	return nil, false
}

func imageURL(base *url.URL, img *goquery.Selection) (string, bool) {
	var best string

	for _, attr := range []string{"data-srcset", "srcset"} {
		if val, ok := img.Attr(attr); ok {
			if u := parseSrcset(val); u != "" {
				if resolved, ok := resolveURL(base, u); ok {
					best = resolved
				}
			}
		}
	}

	if best == "" {
		for _, attr := range []string{
			"data-original",
			"data-lazy-src",
			"data-src",
			"src",
		} {
			if val, ok := img.Attr(attr); ok && val != "" {
				if resolved, ok := resolveURL(base, val); ok {
					best = resolved
					break
				}
			}
		}
	}

	return best, best != ""
}

func resolveURL(base *url.URL, ref string) (string, bool) {
	u, err := base.Parse(ref)
	if err != nil {
		return "", false
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return "", false
	}
	return u.String(), true
}

// parseSrcset picks the highest-resolution candidate from a srcset value.
// Width (w) and pixel-density (x) descriptors aren't directly comparable, so
// they're tracked separately: a width descriptor expresses real pixel
// dimensions and always wins when present, since we want the largest image.
// Only when no w-descriptor candidate exists do we fall back to the highest
// x-descriptor (an absent descriptor being an implicit 1x per the spec).
func parseSrcset(srcset string) string {
	var (
		bestWURL string
		bestW    int
		bestXURL string
		bestX    float64
	)

	for candidate := range strings.SplitSeq(srcset, ",") {
		fields := strings.Fields(strings.TrimSpace(candidate))
		if len(fields) == 0 {
			continue
		}

		rawURL := fields[0]

		if len(fields) == 1 {
			// No descriptor means an implicit 1x per the srcset spec.
			if 1 > bestX {
				bestX = 1
				bestXURL = rawURL
			}
			continue
		}

		d := fields[1]

		if wStr, ok := strings.CutSuffix(d, "w"); ok {
			w, err := strconv.Atoi(wStr)
			if err == nil && w > bestW {
				bestW = w
				bestWURL = rawURL
			}
			continue
		}

		if xStr, ok := strings.CutSuffix(d, "x"); ok {
			x, err := strconv.ParseFloat(xStr, 64)
			if err == nil && x > bestX {
				bestX = x
				bestXURL = rawURL
			}
		}
	}

	if bestWURL != "" {
		return bestWURL
	}
	return bestXURL
}
