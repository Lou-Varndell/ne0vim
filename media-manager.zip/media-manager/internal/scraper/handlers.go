package scraper

import (
	"fmt"
	"log/slog"
	"net/http"
	"strings"

	scrapetpl "media-manager/web/templates/scrape"

	"github.com/alexedwards/scs/v2"
	"github.com/go-chi/chi/v5"
)

type handler struct {
	log      *slog.Logger
	session  *scs.SessionManager
	client   *http.Client
	imageDir string
}

// Mount wires the scraper routes onto r using the given logger, session
// manager, and destination directory for downloaded images. A single shared
// http.Client is created here so connection pooling is preserved across
// requests rather than discarded per request.
func Mount(r chi.Router, log *slog.Logger, session *scs.SessionManager, imageDir string) {
	h := &handler{
		log:      log,
		session:  session,
		client:   newHTTPClient(),
		imageDir: imageDir,
	}

	r.Get("/scrape", h.home)
	r.Post("/parse", h.parse)
	r.Post("/download", h.download)
}

func (h *handler) home(w http.ResponseWriter, r *http.Request) {
	component := scrapetpl.Home()
	if err := component.Render(r.Context(), w); err != nil {
		h.log.Error("render failed", "err", err)
	}
}

func (h *handler) parse(w http.ResponseWriter, r *http.Request) {
	r.Body = http.MaxBytesReader(w, r.Body, maxFormBytes)

	if err := r.ParseForm(); err != nil {
		h.log.Error("parse form failed", "err", err)
		http.Error(w, "invalid form", http.StatusBadRequest)
		return
	}

	rawLines := strings.Split(r.FormValue("text"), "\n")

	var pageURLs []string
	for _, line := range rawLines {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}

		if len(pageURLs) >= maxLines {
			h.log.Warn("line limit exceeded, remaining lines skipped", "limit", maxLines)
			break
		}
		pageURLs = append(pageURLs, line)
	}

	images := collectImages(r.Context(), h.log, h.client, pageURLs)

	h.session.Put(r.Context(), "images", images)

	component := scrapetpl.Lines(images)
	if err := component.Render(r.Context(), w); err != nil {
		h.log.Error("render failed", "err", err)
	}
}

func (h *handler) download(w http.ResponseWriter, r *http.Request) {
	images, ok := h.session.Get(r.Context(), "images").([]string)
	if !ok || len(images) == 0 {
		http.Error(w, "No images in session", http.StatusBadRequest)
		return
	}

	saved := downloadImages(r.Context(), h.log, h.client, h.imageDir, images)

	fmt.Fprintf(
		w,
		`<article class="message is-success">
            <div class="message-body">
                Downloaded %d of %d images.
                <a href="/catalog">View in Catalog</a>
            </div>
        </article>`,
		saved,
		len(images),
	)
	h.session.Remove(r.Context(), "images")
}
