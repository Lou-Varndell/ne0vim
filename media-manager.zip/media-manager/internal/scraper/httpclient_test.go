package scraper

import (
	"net"
	"testing"
)

func TestIsBlockedIP(t *testing.T) {
	cases := []struct {
		name string
		ip   string
		want bool
	}{
		{"loopback", "127.0.0.1", true},
		{"private 10/8", "10.0.0.1", true},
		{"private 192.168/16", "192.168.1.1", true},
		{"link-local metadata", "169.254.169.254", true},
		{"unspecified", "0.0.0.0", true},
		{"cgnat 100.64/10", "100.64.1.1", true},
		{"cgnat upper bound", "100.127.255.255", true},
		{"public", "93.184.216.34", false},
		{"public just below cgnat", "100.63.255.255", false},
		{"public just above cgnat", "100.128.0.0", false},
	}

	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			ip := net.ParseIP(c.ip)
			if ip == nil {
				t.Fatalf("bad test IP %q", c.ip)
			}
			if got := isBlockedIP(ip); got != c.want {
				t.Errorf("isBlockedIP(%s) = %v, want %v", c.ip, got, c.want)
			}
		})
	}
}
