package scraper

import (
	"net/url"
	"testing"
)

func TestParseSrcset(t *testing.T) {
	cases := []struct {
		name   string
		srcset string
		want   string
	}{
		{
			name:   "picks widest w-descriptor",
			srcset: "small.jpg 480w, medium.jpg 800w, large.jpg 1200w",
			want:   "large.jpg",
		},
		{
			name:   "picks highest x-descriptor",
			srcset: "img1x.jpg 1x, img2x.jpg 2x, img3x.jpg 3x",
			want:   "img3x.jpg",
		},
		{
			name:   "single implicit 1x candidate",
			srcset: "only.jpg",
			want:   "only.jpg",
		},
		{
			name:   "empty srcset",
			srcset: "",
			want:   "",
		},
	}

	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			if got := parseSrcset(c.srcset); got != c.want {
				t.Errorf("parseSrcset(%q) = %q, want %q", c.srcset, got, c.want)
			}
		})
	}
}

func TestResolveURL(t *testing.T) {
	base, err := url.Parse("https://example.com/gallery/page.html")
	if err != nil {
		t.Fatalf("parse base: %v", err)
	}

	cases := []struct {
		name   string
		ref    string
		want   string
		wantOK bool
	}{
		{
			name:   "relative path resolves against base",
			ref:    "img/photo.jpg",
			want:   "https://example.com/gallery/img/photo.jpg",
			wantOK: true,
		},
		{
			name:   "absolute https url passes through",
			ref:    "https://cdn.example.com/photo.jpg",
			want:   "https://cdn.example.com/photo.jpg",
			wantOK: true,
		},
		{
			name:   "javascript scheme is rejected",
			ref:    "javascript:alert(1)",
			want:   "",
			wantOK: false,
		},
		{
			name:   "data scheme is rejected",
			ref:    "data:image/png;base64,abc",
			want:   "",
			wantOK: false,
		},
	}

	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got, ok := resolveURL(base, c.ref)
			if ok != c.wantOK {
				t.Fatalf("resolveURL(%q) ok = %v, want %v", c.ref, ok, c.wantOK)
			}
			if ok && got != c.want {
				t.Errorf("resolveURL(%q) = %q, want %q", c.ref, got, c.want)
			}
		})
	}
}
