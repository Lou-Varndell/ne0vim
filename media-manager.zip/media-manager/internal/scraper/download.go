package scraper

import (
	"context"
	"fmt"
	"io"
	"log/slog"
	"mime"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"

	"media-manager/internal/workerpool"

	"github.com/google/uuid"
)

// collectImages fans pageURLs out across a bounded worker pool, fetching
// each page and its candidate images concurrently, and returns every image
// URL found across all pages.
func collectImages(ctx context.Context, log *slog.Logger, session *http.Client, pageURLs []string) []string {
	type result struct {
		images []string
	}

	results := make([]result, len(pageURLs))

	workerpool.Run(ctx, poolWorkers, indices(len(pageURLs)), func(i int) {
		found, err := collectImagesFromPage(ctx, session, pageURLs[i])
		if err != nil {
			log.Error("collect images failed", "url", pageURLs[i], "err", err)
			return
		}
		results[i] = result{images: found}
	})

	var images []string
	for _, res := range results {
		images = append(images, res.images...)
	}
	return images
}

// downloadImages fans images out across a bounded worker pool and returns
// how many were saved successfully.
func downloadImages(ctx context.Context, log *slog.Logger, client *http.Client, imageDir string, images []string) int {
	if err := os.MkdirAll(imageDir, 0o755); err != nil {
		log.Error("create image dir failed", "dir", imageDir, "err", err)
		return 0
	}

	var saved atomic.Int64

	workerpool.Run(ctx, poolWorkers, images, func(img string) {
		if err := downloadImage(ctx, client, imageDir, img); err != nil {
			log.Error("download failed", "url", img, "err", err)
			return
		}
		saved.Add(1)
	})

	return int(saved.Load())
}

// imageExtByType maps an image content type to the file extension used when
// the URL carries none. It doubles as the allowlist of content types we are
// willing to save.
var imageExtByType = map[string]string{
	"image/jpeg": ".jpg",
	"image/png":  ".png",
	"image/gif":  ".gif",
	"image/webp": ".webp",
	"image/bmp":  ".bmp",
	"image/tiff": ".tiff",
	"image/avif": ".avif",
}

// allowedImageExts is the set of URL-supplied extensions we trust; anything
// else falls back to the extension implied by the response Content-Type.
var allowedImageExts = map[string]bool{
	".jpg": true, ".jpeg": true, ".png": true, ".gif": true,
	".webp": true, ".bmp": true, ".tif": true, ".tiff": true, ".avif": true,
}

func downloadImage(ctx context.Context, client *http.Client, imageDir, rawURL string) error {
	req, err := newRequest(ctx, http.MethodGet, rawURL)
	if err != nil {
		return fmt.Errorf("build request for %s: %w", rawURL, err)
	}

	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("fetch %s: %w", rawURL, err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("unexpected status for %s: %s", rawURL, resp.Status)
	}

	// The candidate passed a HEAD content-type check during collection, but a
	// server can serve something else on GET, so re-verify here before we
	// commit bytes to disk. mediaType strips any "; charset=..." parameter.
	mediaType, _, _ := mime.ParseMediaType(resp.Header.Get("Content-Type"))
	if !strings.HasPrefix(mediaType, "image/") {
		return fmt.Errorf("non-image content type for %s: %q", rawURL, mediaType)
	}

	u, err := url.Parse(rawURL)
	if err != nil {
		return fmt.Errorf("parse url %s: %w", rawURL, err)
	}

	// Trust the URL's extension only if it's a known image extension;
	// otherwise derive one from the verified content type.
	ext := strings.ToLower(filepath.Ext(u.Path))
	if !allowedImageExts[ext] {
		if byType, ok := imageExtByType[mediaType]; ok {
			ext = byType
		} else {
			ext = ".jpg"
		}
	}

	name := uuid.NewString() + ext

	f, err := os.Create(filepath.Join(imageDir, name))
	if err != nil {
		return fmt.Errorf("create file for %s: %w", rawURL, err)
	}
	defer f.Close()

	written, err := io.Copy(f, io.LimitReader(resp.Body, maxImageBytes+1))
	if err != nil {
		os.Remove(f.Name())
		return fmt.Errorf("write image %s: %w", rawURL, err)
	}
	if written > maxImageBytes {
		os.Remove(f.Name())
		return fmt.Errorf("image %s exceeds %d byte limit", rawURL, maxImageBytes)
	}

	return nil
}

// indices returns []int{0, 1, ..., n-1}, used to drive collectImages'
// worker pool by index since each worker needs both the URL and its slot
// in the shared results slice.
func indices(n int) []int {
	idx := make([]int, n)
	for i := range idx {
		idx[i] = i
	}
	return idx
}
