module media-manager

go 1.26.4

require github.com/a-h/templ v0.3.1020

require (
	github.com/PuerkitoBio/goquery v1.12.0
	github.com/alexedwards/scs/v2 v2.9.0
	github.com/go-chi/chi/v5 v5.3.0
	github.com/google/uuid v1.6.0
	golang.org/x/image v0.44.0
)

require (
	github.com/andybalholm/cascadia v1.3.3 // indirect
	golang.org/x/net v0.52.0 // indirect
)
