package organize

import (
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"syscall"

	"image-browser/internal/images"
	"image-browser/internal/paths"
)

// Run executes the organize command.
func Run(args []string) error {
	fs := flag.NewFlagSet("organize", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)

	root := fs.String("root", "", "root directory to search (default: ~/Images)")
	dest := fs.String("dest", "", "destination directory")
	execute := fs.Bool("execute", false, "actually move files")

	fs.Usage = func() {
		fmt.Fprintln(os.Stderr, "Usage: image-browser organize [pattern] [flags]")
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "Flags:")
		fs.PrintDefaults()
	}

	if err := fs.Parse(args); err != nil {
		return err
	}

	positional := fs.Args()

	var pattern string
	switch len(positional) {
	case 0:
		// No pattern.
	case 1:
		pattern = positional[0]
	default:
		return errors.New("organize: too many positional arguments")
	}

	if !*execute {
		return errors.New("organize requires --execute")
	}

	if *dest == "" {
		return errors.New("organize --execute requires --dest")
	}

	rootPath := *root
	if rootPath == "" {
		rootPath = paths.DefaultRoot()
	}

	rootPath, err := paths.Abs(rootPath)
	if err != nil {
		return err
	}

	destPath, err := paths.Abs(*dest)
	if err != nil {
		return err
	}

	matches, err := images.Find(rootPath, pattern)
	if err != nil {
		return err
	}

	if len(matches) == 0 {
		fmt.Printf("No images found for %q under %s\n", pattern, rootPath)
		return nil
	}

	if err := os.MkdirAll(destPath, 0o755); err != nil {
		return err
	}

	var failures int

	for _, src := range matches {
		destPathForFile, duplicate, err := images.ResolveDestination(src, destPath)
		if err != nil {
			fmt.Fprintf(
				os.Stderr,
				"  error resolving destination for %s: %v\n",
				paths.RelOrPath(src, rootPath),
				err,
			)
			failures++
			continue
		}

		if duplicate {
			fmt.Printf("  skip (duplicate): %s\n", paths.RelOrPath(src, rootPath))
			continue
		}

		fmt.Printf(
			"  %s -> %s\n",
			paths.RelOrPath(src, rootPath),
			paths.RelOrPath(destPathForFile, rootPath),
		)

		if err := move(src, destPathForFile); err != nil {
			fmt.Fprintf(
				os.Stderr,
				"  error moving %s: %v\n",
				paths.RelOrPath(src, rootPath),
				err,
			)
			failures++
			continue
		}
	}

	if failures > 0 {
		return fmt.Errorf("organize: %d file(s) failed to move", failures)
	}

	return nil
}

// move relocates src to dest, falling back to a copy-then-remove when the
// two paths are on different filesystems.
func move(src, dest string) error {
	if err := os.Rename(src, dest); err == nil {
		return nil
	} else if !errors.Is(err, syscall.EXDEV) {
		return err
	}

	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()

	info, err := in.Stat()
	if err != nil {
		return err
	}

	out, err := os.OpenFile(
		dest,
		os.O_CREATE|os.O_WRONLY|os.O_TRUNC,
		info.Mode(),
	)
	if err != nil {
		return err
	}

	if _, err := io.Copy(out, in); err != nil {
		out.Close()
		os.Remove(dest)
		return err
	}

	if err := out.Close(); err != nil {
		os.Remove(dest)
		return err
	}

	return os.Remove(src)
}
