package images

import (
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"lukechampine.com/blake3"
)

const HashChunkSize = 1 << 20

var Extensions = map[string]struct{}{
	".jpg": {}, ".jpeg": {}, ".png": {}, ".gif": {},
	".bmp": {}, ".tiff": {}, ".webp": {},
}

// Find walks root looking for image files whose path contains pattern
// (case-insensitive). A subdirectory that can't be read (permission denied,
// broken symlink, etc.) is skipped rather than aborting the whole walk; an
// error reading root itself is still returned, since that indicates the
// caller passed a bad starting point rather than an incidental obstruction.
func Find(root, pattern string) ([]string, error) {
	pattern = strings.ToLower(pattern)
	var matches []string

	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			if path == root {
				return err
			}
			if d != nil && d.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}
		if d.IsDir() {
			return nil
		}
		if _, ok := Extensions[strings.ToLower(filepath.Ext(path))]; !ok {
			return nil
		}
		if strings.Contains(strings.ToLower(path), pattern) {
			matches = append(matches, path)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}

	sort.Strings(matches)
	return matches, nil
}

func Hash(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()

	h := blake3.New(32, nil)
	if _, err := io.CopyBuffer(h, f, make([]byte, HashChunkSize)); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

func SameFile(a, b string) (bool, error) {
	ai, err := os.Stat(a)
	if err != nil {
		return false, err
	}
	bi, err := os.Stat(b)
	if err != nil {
		return false, err
	}
	if ai.Size() != bi.Size() {
		return false, nil
	}
	ah, err := Hash(a)
	if err != nil {
		return false, err
	}
	bh, err := Hash(b)
	if err != nil {
		return false, err
	}
	return ah == bh, nil
}

func ResolveDestination(src, destDir string) (string, bool, error) {
	dest := filepath.Join(destDir, filepath.Base(src))
	if _, err := os.Stat(dest); os.IsNotExist(err) {
		return dest, false, nil
	} else if err != nil {
		return "", false, err
	}

	duplicate, err := SameFile(src, dest)
	if err != nil {
		return "", false, err
	}
	if duplicate {
		return "", true, nil
	}

	ext := filepath.Ext(dest)
	stem := strings.TrimSuffix(filepath.Base(dest), ext)
	for n := 2; ; n++ {
		candidate := filepath.Join(destDir, fmt.Sprintf("%s-%d%s", stem, n, ext))
		if _, err := os.Stat(candidate); os.IsNotExist(err) {
			return candidate, false, nil
		} else if err != nil {
			return "", false, err
		}
	}
}
