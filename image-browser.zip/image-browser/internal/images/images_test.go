package images

import (
	"os"
	"path/filepath"
	"runtime"
	"testing"
)

func TestResolveDestination(t *testing.T) {
	dir := t.TempDir()
	src := filepath.Join(dir, "source.jpg")
	dest := filepath.Join(dir, "dest")
	if err := os.Mkdir(dest, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(src, []byte("one"), 0o644); err != nil {
		t.Fatal(err)
	}

	path, duplicate, err := ResolveDestination(src, dest)
	if err != nil {
		t.Fatal(err)
	}
	if duplicate || filepath.Base(path) != "source.jpg" {
		t.Fatalf("unexpected destination: %q duplicate=%v", path, duplicate)
	}
}

func TestFindSkipsUnreadableSubdir(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("chmod-based permission restriction is not portable to windows")
	}
	if os.Geteuid() == 0 {
		t.Skip("root ignores directory permission bits")
	}

	root := t.TempDir()

	blocked := filepath.Join(root, "blocked")
	if err := os.Mkdir(blocked, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(blocked, "hidden.jpg"), []byte("x"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(blocked, 0o000); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { os.Chmod(blocked, 0o755) })

	ok := filepath.Join(root, "ok")
	if err := os.Mkdir(ok, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(ok, "visible.jpg"), []byte("x"), 0o644); err != nil {
		t.Fatal(err)
	}

	matches, err := Find(root, "")
	if err != nil {
		t.Fatalf("Find returned an error instead of skipping the unreadable subdir: %v", err)
	}
	if len(matches) != 1 || filepath.Base(matches[0]) != "visible.jpg" {
		t.Fatalf("expected only visible.jpg, got %v", matches)
	}
}
