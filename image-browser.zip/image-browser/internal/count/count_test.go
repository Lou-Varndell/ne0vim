package count

import (
	"os"
	"path/filepath"
	"testing"
)

func TestCountImages(t *testing.T) {
	root := t.TempDir()

	files := []string{
		"one.jpg", "two.JPG", "three.png", "four.webp",
		"not-an-image.txt", "nested/five.jpeg", "nested/six.HEIC",
	}

	for _, name := range files {
		path := filepath.Join(root, name)
		if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, nil, 0o644); err != nil {
			t.Fatal(err)
		}
	}

	got, err := countImages(root)
	if err != nil {
		t.Fatal(err)
	}
	if want := 6; got != want {
		t.Fatalf("countImages() = %d, want %d", got, want)
	}
}
