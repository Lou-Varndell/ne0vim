package count

import (
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"image-browser/internal/paths"
)

var imageExtensions = map[string]bool{
	".jpg": true, ".jpeg": true, ".png": true, ".gif": true,
	".bmp": true, ".tif": true, ".tiff": true, ".webp": true,
	".avif": true, ".heic": true,
}

// Run executes the count command.
func Run(args []string) error {
	fs := flag.NewFlagSet("count", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)

	root := fs.String("root", "", "root directory to search (default: current directory)")

	fs.Usage = func() {
		fmt.Fprintln(os.Stderr, "Usage: image-browser count [flags]")
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "Flags:")
		fs.PrintDefaults()
	}

	if err := fs.Parse(args); err != nil {
		return err
	}

	if len(fs.Args()) > 0 {
		return fmt.Errorf("count: unexpected argument: %s", fs.Args()[0])
	}

	rootPath := *root
	if rootPath == "" {
		rootPath = "."
	}

	rootPath, err := paths.Abs(rootPath)
	if err != nil {
		return err
	}

	info, err := os.Stat(rootPath)
	if err != nil {
		return fmt.Errorf("not a directory: %s", rootPath)
	}
	if !info.IsDir() {
		return fmt.Errorf("not a directory: %s", rootPath)
	}

	entries, err := os.ReadDir(rootPath)
	if err != nil {
		return err
	}

	var subdirs []string
	for _, entry := range entries {
		if entry.IsDir() {
			subdirs = append(subdirs, entry.Name())
		}
	}
	sort.Strings(subdirs)

	for _, name := range subdirs {
		subdir := filepath.Join(rootPath, name)
		imageCount, err := countImages(subdir)
		if err != nil {
			return err
		}
		fmt.Printf("%05d %s\n", imageCount, subdir)
	}

	return nil
}

func countImages(root string) (int, error) {
	count := 0

	err := filepath.WalkDir(root, func(path string, entry os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if entry.IsDir() || !entry.Type().IsRegular() {
			return nil
		}
		if imageExtensions[strings.ToLower(filepath.Ext(entry.Name()))] {
			count++
		}
		return nil
	})

	return count, err
}
