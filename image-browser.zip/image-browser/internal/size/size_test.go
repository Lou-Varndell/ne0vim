package size

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"testing"
)

func TestLoadGroupsByResolutionAndDeduplicatesFiles(t *testing.T) {
	root := t.TempDir()
	manifest := filepath.Join(root, "image-manifest.json")

	records := []ManifestRecord{
		{File: "/images/b.jpg", Width: intPtr(400), Height: intPtr(600)},
		{File: "/images/a.jpg", Width: intPtr(400), Height: intPtr(600)},
		{File: "/images/a.jpg", Width: intPtr(400), Height: intPtr(600)},
		{File: "/images/c.jpg", Width: intPtr(800), Height: intPtr(600)},
		{File: "/images/ignored.jpg", Width: nil, Height: intPtr(600)},
	}

	data, err := json.Marshal(records)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(manifest, data, 0o644); err != nil {
		t.Fatal(err)
	}

	groups, err := Load(manifest)
	if err != nil {
		t.Fatal(err)
	}

	if len(groups) != 2 {
		t.Fatalf("Load() returned %d groups, want 2", len(groups))
	}

	SortGroups(groups, false)

	want := []Group{
		{Width: 400, Height: 600, Files: []string{"/images/a.jpg", "/images/b.jpg"}},
		{Width: 800, Height: 600, Files: []string{"/images/c.jpg"}},
	}

	if !reflect.DeepEqual(groups, want) {
		t.Fatalf("Load() groups = %#v, want %#v", groups, want)
	}
}

func TestSortGroupsLargestFirst(t *testing.T) {
	groups := []Group{
		{Width: 400, Height: 600},
		{Width: 1800, Height: 1200},
		{Width: 800, Height: 600},
	}

	SortGroups(groups, true)

	want := []Group{
		{Width: 1800, Height: 1200},
		{Width: 800, Height: 600},
		{Width: 400, Height: 600},
	}

	if !reflect.DeepEqual(groups, want) {
		t.Fatalf("SortGroups() = %#v, want %#v", groups, want)
	}
}

func intPtr(v int) *int {
	return &v
}
