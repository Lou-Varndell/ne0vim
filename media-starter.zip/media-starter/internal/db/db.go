package db

import "database/sql"

func Init(db *sql.DB) error {
    _, err := db.Exec(`
        CREATE TABLE IF NOT EXISTS media (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            filename TEXT NOT NULL UNIQUE
        );
    `)
    return err
}
