package main

import (
    "database/sql"
    "log"
    "net/http"

    "github.com/a-h/templ"
    "github.com/go-chi/chi/v5"
    _ "github.com/mattn/go-sqlite3"

    "github.com/example/media-starter/internal/db"
    "github.com/example/media-starter/views"
)

func main() {
    conn, err := sql.Open("sqlite3", "media.db")
    if err != nil {
        log.Fatal(err)
    }
    defer conn.Close()

    if err := db.Init(conn); err != nil {
        log.Fatal(err)
    }

    r := chi.NewRouter()

    r.Get("/", func(w http.ResponseWriter, r *http.Request) {
        templ.Handler(views.Index()).ServeHTTP(w, r)
    })

    r.Get("/healthz", func(w http.ResponseWriter, r *http.Request) {
        w.Write([]byte("ok"))
    })

    log.Println("Listening on :3000")
    log.Fatal(http.ListenAndServe(":3000", r))
}
