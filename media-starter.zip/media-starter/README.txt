Media Starter

Install: - go install github.com/a-h/templ/cmd/templ@latest

Run: - templ generate - go run ./cmd/server

Open http://localhost:3000
