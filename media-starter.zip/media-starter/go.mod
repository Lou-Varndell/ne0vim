module github.com/example/media-starter

go 1.25

require (
    github.com/a-h/templ v0.3.960
    github.com/go-chi/chi/v5 v5.2.3
    github.com/mattn/go-sqlite3 v1.14.32
)
