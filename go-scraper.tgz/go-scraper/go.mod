module main

go 1.26.4

require (
	github.com/PuerkitoBio/goquery v1.12.0
	github.com/hashicorp/go-retryablehttp v0.7.8
	github.com/zeebo/blake3 v0.2.4
)

require (
	github.com/andybalholm/cascadia v1.3.3 // indirect
	github.com/hashicorp/go-cleanhttp v0.5.2 // indirect
	github.com/klauspost/cpuid/v2 v2.0.12 // indirect
	golang.org/x/net v0.52.0 // indirect
)
