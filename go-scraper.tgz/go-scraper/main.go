package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"github.com/PuerkitoBio/goquery"
)

const (
	HASHCHUNKSIZE  = 1 << 20 // 1 MiB
	DEFAULTTIMEOUT = 30 * time.Second
)

var (
	re = regexp.MustCompile(`[^\w.-]+`)
)

func createSession() *http.Client {
	transport := &http.Transport{
		MaxIdleConns:        100,
		MaxIdleConnsPerHost: 10,
		IdleConnTimeout:     30 * time.Second,
	}

	client := &http.Client{
		Transport: transport,
		Timeout:   DEFAULTTIMEOUT,
	}

	return client
}

func getBaseURL(pageURL string) *url.URL {
	base, _ := url.Parse(pageURL)
	return base
}

func downloadImages(session *http.Client, pageURL, selector, outputDir string) error {
	outputDir = filepath.Clean(outputDir)
	if err := os.MkdirAll(outputDir, 0755); err != nil {
		return fmt.Errorf("failed to create output directory: %w", err)
	}

	resp, err := session.Get(pageURL)
	if err != nil {
		return fmt.Errorf("failed to fetch page: %w", err)
	}
	defer resp.Body.Close()

	doc, err := goquery.NewDocumentFromReader(resp.Body)
	if err != nil {
		return fmt.Errorf("failed to parse HTML: %w", err)
	}

	doc.Find(selector).Each(func(i int, s *goquery.Selection) {
		imgSrc, exists := s.Attr("src")
		if !exists {
			imgSrc, exists = s.Attr("data-src")
		}
		if !exists {
			imgSrc, exists = s.Attr("srcset")
		}

		if !exists {
			return
		}

		parsedURL, err := url.Parse(imgSrc)
		if err != nil {
			slog.Warn("Failed to parse image URL", "image_url", imgSrc)
			return
		}

		if !parsedURL.IsAbs() {
			base := getBaseURL(pageURL)
			parsedURL = base.ResolveReference(parsedURL)
		}

		filename := filepath.Base(parsedURL.Path)
		if filename == "." || filename == "" {
			slog.Warn("Skipping URL without filename", "image_url", imgSrc)
			return
		}

		destPath := filepath.Join(outputDir, filename)

		if _, err := os.Stat(destPath); err == nil {
			slog.Info("Skipping existing file", "filename", filename)
			return
		}

		imgResp, err := session.Get(parsedURL.String())
		if err != nil {
			slog.Error("Failed to download image", "image_url", parsedURL.String(), "error", err)
			return
		}
		defer imgResp.Body.Close()

		out, err := os.Create(destPath)
		if err != nil {
			slog.Error("Failed to create file", "filename", filename, "error", err)
			return
		}
		defer out.Close()

		if _, err := io.Copy(out, imgResp.Body); err != nil {
			slog.Error("Failed to write image", "filename", filename, "error", err)
			return
		}
		slog.Info("Downloaded image", "filename", filename)
	})

	return nil
}

func checksumFile(path string) (string, error) {
	file, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer file.Close()

	hasher := sha256.New()
	buffer := make([]byte, HASHCHUNKSIZE)

	for {
		n, err := file.Read(buffer)
		if n > 0 {
			hasher.Write(buffer[:n])
		}
		if err != nil {
			if err == io.EOF {
				break
			}
			return "", err
		}
	}

	return hex.EncodeToString(hasher.Sum(nil)), nil
}

func extract(session *http.Client, pageURL string) (map[string]string, error) {
	resp, err := session.Get(pageURL)
	if err != nil {
		return nil, fmt.Errorf("failed to fetch page: %w", err)
	}
	defer resp.Body.Close()

	doc, err := goquery.NewDocumentFromReader(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to parse HTML: %w", err)
	}

	img := doc.Find("img[alt='Rate this image']")
	if img.Length() == 0 {
		return nil, nil
	}

	imgSrc, _ := img.Attr("src")
	if imgSrc == "" {
		return nil, nil
	}

	// Handle relative URLs
	parsedURL, err := url.Parse(imgSrc)
	if err != nil {
		return nil, fmt.Errorf("failed to parse image URL: %w", err)
	}

	if !parsedURL.IsAbs() {
		base, _ := url.Parse(pageURL)
		parsedURL = base.ResolveReference(parsedURL)
	}

	// Find container and title
	container := img.Parent()
	for container.Length() > 0 {
		h3 := container.Find("h3")
		if h3.Length() > 0 {
			link := h3.Find("a")
			if link.Length() > 0 {
				href, _ := link.Attr("href")
				title, _ := link.Html()
				return map[string]string{
					"page_url":  href,
					"title":     strings.TrimSpace(title),
					"image_url": parsedURL.String(),
				}, nil
			}
		}
		container = container.Parent()
	}

	return nil, nil
}

func previewImage(session *http.Client, imageURL string) error {
	resp, err := session.Get(imageURL)
	if err != nil {
		return fmt.Errorf("failed to fetch image: %w", err)
	}
	defer resp.Body.Close()

	content, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("failed to read image: %w", err)
	}

	// Create temporary file and open it
	tmpFile, err := os.CreateTemp("", "preview_*.jpg")
	if err != nil {
		return fmt.Errorf("failed to create temp file: %w", err)
	}
	defer os.Remove(tmpFile.Name())
	defer tmpFile.Close()

	_, err = tmpFile.Write(content)
	if err != nil {
		return fmt.Errorf("failed to write temp file: %w", err)
	}

	// Try to open the image using system default viewer
	cmd := exec.Command("open", tmpFile.Name())
	err = cmd.Start()
	if err != nil {
		slog.Error("Failed to open image preview", "image_url", imageURL, "error", err)
	} else {
		slog.Info("Image preview opened", "image_url", imageURL)
	}

	return nil
}

func main() {
	session := createSession()
	pageURL := ""

	data, err := extract(session, pageURL)
	if err != nil {
		slog.Error("Failed to extract data", "error", err)
		return
	}

	if data == nil {
		slog.Info("No image found.")
		return
	}

	slog.Info("Found image", "title", data["title"], "page_url", data["page_url"], "image_url", data["image_url"])

	// Preview the image
	err = previewImage(session, data["image_url"])
	if err != nil {
		slog.Error("Failed to preview image", "error", err, "image_url", data["image_url"])
	}

	safeTitle := re.ReplaceAllString(data["title"], "_")
	safeTitle = strings.Trim(safeTitle, "_")

	err = downloadImages(session, data["page_url"], "div.gallery img", safeTitle)
	if err != nil {
		slog.Error("Failed to download images", "error", err)
	}

	// Simulate pbcopy functionality using clipboard package or shell command
	// For simplicity, we'll just print to stdout in Go
	fmt.Println("To copy image URLs to clipboard, run:")
	fmt.Println("copy([...document.images].map(img => img.src).join('\\n'));")
}
