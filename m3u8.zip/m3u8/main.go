package main

import (
	"bufio"
	"bytes"
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"log/slog"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"github.com/PuerkitoBio/goquery"
	"github.com/google/uuid"
	"github.com/grafov/m3u8"
)

const (
	dialTimeout        = 10 * time.Second
	readTimeout        = 60 * time.Second
	maxIdleConnections = 8
	userAgent          = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) " +
		"AppleWebKit/537.36 (KHTML, like Gecko) " +
		"Chrome/148.0.0.0 Safari/537.36"
)

var (
	re                = regexp.MustCompile(`https://[^']+\.m3u8`)
	invalidFilenameRE = regexp.MustCompile(`[<>:"/\\|?*]`)
)

func codecRank(codecs string) int {
	codecs = strings.ToLower(codecs)

	for _, c := range strings.Split(codecs, ",") {
		c = strings.TrimSpace(c)

		switch {
		case strings.HasPrefix(c, "av01"):
			return 5 // AV1

		case strings.HasPrefix(c, "hvc1"),
			strings.HasPrefix(c, "hev1"):
			return 4 // HEVC / H.265

		case strings.HasPrefix(c, "vp09"):
			return 3 // VP9

		case strings.HasPrefix(c, "avc1"):
			return 2 // H.264

		case strings.HasPrefix(c, "vp8"):
			return 1 // VP8
		}
	}

	return 0
}

func downloadVideo(ctx context.Context, variantURL, filename string) error {
	cmd := exec.CommandContext(ctx,
		"ffmpeg",
		"-i", variantURL,
		"-c", "copy",
		filename,
	)

	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr

	return cmd.Run()
}

func extractHLSURL(body []byte) (string, error) {
	err := os.WriteFile("/Users/boomer/dev/go/m3u8/temp.html", body, 0644)
	if err != nil {
		return "", err
	}

	hls := re.FindString(string(body))
	if hls == "" {
		slog.Error("no HLS URL found")
		return "", errors.New("no HLS URL found")
	}

	return hls, nil
}

func extractTitle(title string) string {
	return sanitizeFilename(strings.ReplaceAll(strings.TrimSpace(title), " ", "_"))
}

func fetchPage(ctx context.Context, client *http.Client, url string) ([]byte, error) {
	resp, err := get(ctx, client, url)
	if err != nil {
		slog.Error("failed to get page", "url", url, "error", err.Error())
		return nil, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		slog.Error("failed to read response body", "error", err.Error())
		return nil, err
	}

	return body, nil
}

func get(ctx context.Context, client *http.Client, url string) (*http.Response, error) {
	req, err := newRequest(ctx, http.MethodGet, url)
	if err != nil {
		return nil, err
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}

	if resp.StatusCode != http.StatusOK {
		resp.Body.Close()
		return nil, fmt.Errorf("unexpected status: %s", resp.Status)
	}
	return resp, nil
}

func isBetterVariant(a, b *m3u8.Variant) bool {
	aw, ah := parseResolution(a.Resolution)
	bw, bh := parseResolution(b.Resolution)

	// Prefer higher pixel count.
	if aw*ah != bw*bh {
		return aw*ah > bw*bh
	}

	aRank := codecRank(a.Codecs)
	bRank := codecRank(b.Codecs)

	if aRank != bRank {
		return aRank > bRank
	}

	// Prefer average bandwidth if present.
	aBW := a.AverageBandwidth
	if aBW == 0 {
		aBW = a.Bandwidth
	}

	bBW := b.AverageBandwidth
	if bBW == 0 {
		bBW = b.Bandwidth
	}

	if aBW != bBW {
		return aBW > bBW
	}

	// Finally, prefer higher frame rate.
	return a.FrameRate > b.FrameRate
}

func newHTTPClient() *http.Client {
	dialer := &net.Dialer{Timeout: dialTimeout}
	return &http.Client{
		Timeout: readTimeout,
		Transport: &http.Transport{
			DialContext:           dialer.DialContext,
			MaxIdleConns:          maxIdleConnections,
			MaxIdleConnsPerHost:   maxIdleConnections,
			MaxConnsPerHost:       8,
			IdleConnTimeout:       30 * time.Second,
			ResponseHeaderTimeout: 15 * time.Second,
			TLSHandshakeTimeout:   10 * time.Second,
			ExpectContinueTimeout: time.Second,
			ForceAttemptHTTP2:     true,
		},
	}
}

func newRequest(ctx context.Context, method, rawURL string) (*http.Request, error) {
	req, err := http.NewRequestWithContext(ctx, method, rawURL, nil)
	if err != nil {
		return nil, err
	}

	req.Header.Set("User-Agent", userAgent)

	return req, nil
}

func main() {
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()

	var (
		useClipboard = flag.Bool("clipboard", false, "read input from the system clipboard")
		site         = flag.String("site", "", "site to scrape")
		inputFile    = flag.String("input", "", "input file containing URLs")
	)

	flag.Parse()

	arg := flag.Arg(0)

	var sites []string

	switch {
	case arg != "":
		var err error
		sites, err = readLines(arg)
		if err != nil {
			slog.Error("failed", "err", err)
			os.Exit(1)
		}
	case *inputFile != "":
		var err error
		sites, err = readLines(*inputFile)
		if err != nil {
			slog.Error("reading", "file", *inputFile, "error", err.Error())
		}

	case *site != "":
		sites = []string{*site}

	case *useClipboard:
		lines, err := readClipboard()
		if err != nil {
			slog.Error("failed to read clipboard", "error", err.Error())
			os.Exit(1)
		}
		sites = lines

	default:
		var err error
		sites, err = readLines("input.txt")
		if err != nil {
			slog.Error("failed to read input.txt", "error", err.Error())
		}
	}

	slog.Info("processing sites", "count", len(sites), "sites", sites)

	// if err := run(ctx, sites); err != nil {
	if err := run(ctx, sites); err != nil {
		slog.Error("download failed", "error", err)
		os.Exit(1)
	}
}

func parseResolution(res string) (width, height int) {
	_, err := fmt.Sscanf(res, "%dx%d", &width, &height)
	if err != nil {
		return 0, 0
	}

	return
}

func readClipboard() ([]string, error) {
	out, err := exec.Command("pbpaste").Output()
	if err != nil {
		slog.Error("clipboard read failed", "error", err.Error())
	}

	var lines []string

	scanner := bufio.NewScanner(bytes.NewReader(out))
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}
		lines = append(lines, line)
	}

	if err := scanner.Err(); err != nil {
		return nil, err
	}

	return lines, nil
}

func readLines(filename string) ([]string, error) {
	f, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	var lines []string

	scanner := bufio.NewScanner(f)

	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}
		lines = append(lines, line)
	}

	if err := scanner.Err(); err != nil {
		return nil, err
	}
	return lines, nil
}

func resolveVariantURL(masterURL string, v *m3u8.Variant) (string, error) {
	base, err := url.Parse(masterURL)
	if err != nil {
		return "", err
	}

	ref, err := url.Parse(v.URI)
	if err != nil {
		return "", err
	}

	return base.ResolveReference(ref).String(), nil
}

func run(ctx context.Context, sites []string) error {
	home, err := os.UserHomeDir()
	if err != nil {
		return fmt.Errorf("failed to get home directory: %w", err)
	}

	client := newHTTPClient()

	for _, site := range sites {
		if err := func(site string) error {
			body, err := fetchPage(ctx, client, site)
			if err != nil {
				return fmt.Errorf("failed to get site: %w", err)
			}

			doc, err := goquery.NewDocumentFromReader(bytes.NewReader(body))
			if err != nil {
				return fmt.Errorf("goquery failed %s: %w", site, err)
			}

			title := extractTitle(doc.Find("title").Text())

			hls, err := extractHLSURL(body)
			if err != nil {
				return fmt.Errorf("extract HLS URL failed: %w", err)
			}

			hlsResp, err := get(ctx, client, hls)
			if err != nil {
				return fmt.Errorf("fetch HLS failed %q: %w", hls, err)
			}
			if hlsResp.StatusCode != http.StatusOK {
				return fmt.Errorf("unexpected status %d for %s", hlsResp.StatusCode, hls)
			}
			defer hlsResp.Body.Close()

			playlist, listType, err := m3u8.DecodeFrom(hlsResp.Body, true)
			if err != nil {
				return fmt.Errorf("decode HLS playlist: %w", err)
			}

			switch listType {
			case m3u8.MASTER:
				master := playlist.(*m3u8.MasterPlaylist)

				best, err := selectBestVariant(master)
				if err != nil {
					return fmt.Errorf("select best variant failed: %w", err)
				}

				variantURL, err := resolveVariantURL(hls, best)
				if err != nil {
					return fmt.Errorf("resolve variant url failed: %w", err)
				}

				u, err := url.Parse(best.URI)
				if err != nil {
					return fmt.Errorf("url parse error %s: %w", best.URI, err)
				}

				base := filepath.Base(u.Path)
				base = strings.TrimSuffix(base, filepath.Ext(base))

				filename := filepath.Join(home, "Movies", title+"-"+base+".mkv")

				if err := downloadVideo(ctx, variantURL, filename); err != nil {
					return fmt.Errorf("download video failed %s: %w", variantURL, err)
				}
			case m3u8.MEDIA:
			}

			return nil
		}(site); err != nil {
			slog.Error("site processing failed", "site", site, "error", err.Error())
			continue
		}
	}

	return nil
}

func sanitizeFilename(s string) string {
	s = invalidFilenameRE.ReplaceAllString(s, "_")
	s = strings.TrimSpace(s)

	switch s {
	case "", ".", "..":
		return uuid.NewString()
	}

	return s
}

func selectBestVariant(master *m3u8.MasterPlaylist) (*m3u8.Variant, error) {
	var best *m3u8.Variant

	if master == nil {
		return nil, errors.New("nil master playlist")
	}

	if len(master.Variants) == 0 {
		return nil, errors.New("master playlist has no variants")
	}

	for _, v := range master.Variants {
		if v == nil {
			continue
		}
		if best == nil || isBetterVariant(v, best) {
			best = v
		}
	}

	if best == nil {
		return nil, errors.New("no valid variants")
	}

	return best, nil
}
