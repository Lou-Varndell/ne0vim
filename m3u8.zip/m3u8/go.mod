module main

go 1.26.4

require (
	github.com/PuerkitoBio/goquery v1.12.0
	github.com/google/uuid v1.6.0
	github.com/grafov/m3u8 v0.12.1
)

require (
	github.com/andybalholm/cascadia v1.3.3 // indirect
	golang.org/x/net v0.52.0 // indirect
)
