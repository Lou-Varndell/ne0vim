#!/usr/bin/env python3

from pathlib import Path
from bs4 import BeautifulSoup
import httpx

# https://www.my-ford.com/model/mustang/
# https://www.my-ford.com/model/bronco/
# https://www.my-ford.com/model/highboy/
# https://www.my-ford.com/model/gt50/
# https://www.my-ford.com/model/ltd/

response = httpx.get("https://www.my-ford.com/model/ltd/page/6/")

if response.status_code == 200:
    with Path("output.html").open("w") as fout:
        fout.write(response.text)

    soup = BeautifulSoup(response.text, "lxml")
    with Path("output.txt").open("w") as fout:
        # for i, img in enumerate(soup.select("img"), start=1):
        #   link = img.find_parent("a")["href"]
        #   get parent link of the image
        for i, a in enumerate(soup.select("a"), start=1):
            href = a.get("href")
            if not href:
                continue

            fout.write(href + "\n")
