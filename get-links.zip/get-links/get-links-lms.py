#!/usr/bin/env python3

from pathlib import Path
from bs4 import BeautifulSoup
import httpx
import time


headers = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/138.0.0.0 Safari/537.36"
    )
}

# List of model URLs to process
model_urls = [
    "https://www.my-ford.com/model/mustang/",
    "https://www.my-ford.com/model/bronco/",
    "https://www.my-ford.com/model/highboy/",
    "https://www.my-ford.com/model/gt50/",
    "https://www.my-ford.com/model/ltd/",
]

# Output file
output_file = "output.txt"


# Function to extract all links from a page
def extract_links_from_page(html_content):
    soup = BeautifulSoup(html_content, "lxml")
    links = set()  # Use set to avoid duplicates

    for a in soup.select("a"):
        href = a.get("href")
        if href:
            links.add(href)

    return links


# Function to process all pages for a given URL
def process_model_url(base_url, output_file):
    page_number = 1
    all_links = set()

    while True:
        # Construct the URL for current page
        page_url = f"{base_url.rstrip('/')}/page/{page_number}/"

        try:
            response = httpx.get(
                page_url,
                headers=headers,
                follow_redirects=True,
                timeout=10,
            )

            print(response.status_code)
            print(response.headers.get("Location"))
            print(response.url)

            # If we get a 404, stop processing this model
            if response.status_code == 404:
                print(
                    f"Model {base_url} reached page {page_number - 1} (404) - stopping"
                )
                break

            # If we get a 200, process the page
            if response.is_success or response.is_redirect:
                print(f"Processing {base_url} - page {page_number}")
                links = extract_links_from_page(response.text)
                all_links.update(links)

                # Add delay to be respectful to the server
                time.sleep(0.5)
            else:
                # For any other status code, stop processing
                print(
                    f"Model {base_url} - page {page_number} returned status code {response.status_code}"
                )
                break

        except httpx.RequestError as e:
            print(f"Request error for {page_url}: {e}")
            break

        page_number += 1

    # Write all unique links to file
    with Path(output_file).open("a") as f:
        for link in all_links:
            f.write(link + "\n")

    print(f"Model {base_url} - collected {len(all_links)} unique links")


# Main execution
def main():
    # Clear the output file first
    # with Path(output_file).open("a") as fout:
    #     fout.write("")

    # Process each model URL
    for model_url in model_urls:
        print(f"Starting to process: {model_url}")
        process_model_url(model_url, output_file)
        print(f"Completed processing: {model_url}")


if __name__ == "__main__":
    main()
