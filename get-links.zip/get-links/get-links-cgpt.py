#!/usr/bin/env python3

# You don't actually need nested loops over URLs and pages. The cleanest approach is:

# One outer loop over your model URLs.
# One inner while loop that increments the page number until it gets a 404.
# Write links to output.txt as you go.

# I'd also recommend using an httpx.Client() so you're not creating a new connection for every request.

from pathlib import Path
from bs4 import BeautifulSoup
import httpx

urls = [
    "https://www.my-ford.com/model/mustang/",
    "https://www.my-ford.com/model/bronco/",
    "https://www.my-ford.com/model/highboy/",
    "https://www.my-ford.com/model/gt50/",
    "https://www.my-ford.com/model/ltd/",
]

with (
    httpx.Client(follow_redirects=True) as client,
    Path("output.txt").open("w") as fout,
):
    for base_url in urls:
        page = 1

        while True:
            if page == 1:
                url = base_url
            else:
                url = f"{base_url}page/{page}/"

            response = client.get(url)

            if response.status_code == 404:
                print(f"Finished {base_url} ({page - 1} pages)")
                break

            if response.status_code != 200:
                print(f"{url} returned {response.status_code}")
                break

            print(url)

            soup = BeautifulSoup(response.text, "lxml")

            for a in soup.select("a[href]"):
                fout.write(a["href"] + "\n")

            page += 1

# instead of finishing one model before starting the next. That can also be done with just one while loop by keeping track of which URLs are still active:
# Models automatically drop out once they return a 404, while the remaining models continue. From your wording ("the other urls that return 200 continue"), this second approach seems closer to what you're aiming for.

page = 1
active = urls[:]

while active:
    next_active = []

    for base in active:
        url = base if page == 1 else f"{base}page/{page}/"

        r = client.get(url)

        if r.status_code == 404:
            print(f"{base} finished")
            continue

        if r.status_code != 200:
            print(f"{url}: {r.status_code}")
            continue

        soup = BeautifulSoup(r.text, "lxml")

        for a in soup.select("a[href]"):
            fout.write(a["href"] + "\n")

        next_active.append(base)

    active = next_active
    page += 1
