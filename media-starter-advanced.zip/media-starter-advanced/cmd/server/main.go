// See chat response for full implementation
