// WAL mode initialization
