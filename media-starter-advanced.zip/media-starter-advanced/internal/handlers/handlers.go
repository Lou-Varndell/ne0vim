// HTMX handlers and WalkDir scan
